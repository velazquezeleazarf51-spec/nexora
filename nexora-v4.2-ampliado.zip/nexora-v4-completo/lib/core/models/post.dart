class Post {
  final String id;
  final String userId;
  final String? content;
  final String? mediaUrl;
  final String? mediaType; // image, video, document
  final bool isShortVideo;
  final int? videoDurationSeconds;
  final String? category;
  final bool downloadEnabled;
  final String? downloadableFileUrl;
  final String moderationStatus;
  final bool isApproved;
  final int likesCount;
  final int commentsCount;
  final DateTime createdAt;
  final String? authorUsername;
  final String? authorDisplayName;
  final String? authorAvatarUrl;
  final bool isCreator;

  const Post({
    required this.id,
    required this.userId,
    this.content,
    this.mediaUrl,
    this.mediaType,
    this.isShortVideo = false,
    this.videoDurationSeconds,
    this.category,
    this.downloadEnabled = false,
    this.downloadableFileUrl,
    this.moderationStatus = 'approved',
    this.isApproved = true,
    this.likesCount = 0,
    this.commentsCount = 0,
    required this.createdAt,
    this.authorUsername,
    this.authorDisplayName,
    this.authorAvatarUrl,
    this.isCreator = false,
  });

  factory Post.fromMap(Map<String, dynamic> map) {
    final author = map['profiles'] as Map<String, dynamic>?;
    return Post(
      id: map['id'] as String,
      userId: map['user_id'] as String,
      content: map['content'] as String?,
      mediaUrl: map['media_url'] as String?,
      mediaType: map['media_type'] as String?,
      isShortVideo: map['is_short_video'] == true,
      videoDurationSeconds: map['video_duration_seconds'] as int?,
      category: map['category'] as String? ?? map['content_category'] as String?,
      downloadEnabled: map['download_enabled'] == true || map['allow_download'] == true,
      downloadableFileUrl: map['downloadable_file_url'] as String?,
      moderationStatus: map['moderation_status'] as String? ?? 'approved',
      isApproved: map['is_approved'] != false,
      likesCount: (map['likes_count'] as num?)?.toInt() ?? 0,
      commentsCount: (map['comments_count'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.parse(map['created_at'].toString()),
      authorUsername: author?['username'] as String?,
      authorDisplayName: author?['display_name'] as String? ?? author?['full_name'] as String?,
      authorAvatarUrl: author?['avatar_url'] as String?,
      isCreator: author?['is_creator'] == true,
    );
  }
}
