class Profile {
  final String id;
  final String? username;
  final String? displayName;
  final String? avatarUrl;
  final String? bio;
  final bool isCreator;
  final String? creatorBio;
  final String? coverUrl;
  final String themeColor;
  final String themeMode;
  final String? backgroundUrl;
  final bool onboardingCompleted;
  final DateTime? ageVerifiedAt;
  final String? privacyPolicyVersion;
  final Map<String, dynamic> cookiePreferences;
  final List<String> interests;
  final bool isAdmin;
  final DateTime? createdAt;

  const Profile({
    required this.id,
    this.username,
    this.displayName,
    this.avatarUrl,
    this.bio,
    this.isCreator = false,
    this.creatorBio,
    this.coverUrl,
    this.themeColor = '#8B7CF6',
    this.themeMode = 'dark',
    this.backgroundUrl,
    this.onboardingCompleted = false,
    this.ageVerifiedAt,
    this.privacyPolicyVersion,
    this.cookiePreferences = const {'necessary': true, 'analytics': false, 'marketing': false},
    this.interests = const [],
    this.isAdmin = false,
    this.createdAt,
  });

  factory Profile.fromMap(Map<String, dynamic> map) {
    return Profile(
      id: map['id'] as String,
      username: map['username'] as String?,
      displayName: map['display_name'] as String? ?? map['full_name'] as String?,
      avatarUrl: map['avatar_url'] as String?,
      bio: map['bio'] as String?,
      isCreator: map['is_creator'] == true,
      creatorBio: map['creator_bio'] as String?,
      coverUrl: map['cover_url'] as String?,
      themeColor: map['theme_color'] as String? ?? '#8B7CF6',
      themeMode: map['theme_mode'] as String? ?? 'dark',
      backgroundUrl: map['background_url'] as String?,
      onboardingCompleted: map['onboarding_completed'] == true,
      ageVerifiedAt: map['age_verified_at'] != null
          ? DateTime.tryParse(map['age_verified_at'].toString())
          : null,
      privacyPolicyVersion: map['privacy_policy_version'] as String?,
      cookiePreferences: Map<String, dynamic>.from(
        map['cookie_preferences'] as Map? ??
            {'necessary': true, 'analytics': false, 'marketing': false},
      ),
      interests: List<String>.from(map['interests'] as List? ?? []),
      isAdmin: map['is_admin'] == true,
      createdAt: map['created_at'] != null
          ? DateTime.tryParse(map['created_at'].toString())
          : null,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'username': username,
        'display_name': displayName,
        'avatar_url': avatarUrl,
        'bio': bio,
        'is_creator': isCreator,
        'creator_bio': creatorBio,
        'cover_url': coverUrl,
        'theme_color': themeColor,
        'theme_mode': themeMode,
        'background_url': backgroundUrl,
        'onboarding_completed': onboardingCompleted,
        'age_verified_at': ageVerifiedAt?.toIso8601String(),
        'privacy_policy_version': privacyPolicyVersion,
        'cookie_preferences': cookiePreferences,
        'interests': interests,
      };

  Profile copyWith({
    String? username,
    String? displayName,
    String? avatarUrl,
    String? bio,
    bool? isCreator,
    String? creatorBio,
    String? coverUrl,
    String? themeColor,
    String? themeMode,
    String? backgroundUrl,
    bool? onboardingCompleted,
    DateTime? ageVerifiedAt,
    String? privacyPolicyVersion,
    Map<String, dynamic>? cookiePreferences,
    List<String>? interests,
  }) {
    return Profile(
      id: id,
      username: username ?? this.username,
      displayName: displayName ?? this.displayName,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      bio: bio ?? this.bio,
      isCreator: isCreator ?? this.isCreator,
      creatorBio: creatorBio ?? this.creatorBio,
      coverUrl: coverUrl ?? this.coverUrl,
      themeColor: themeColor ?? this.themeColor,
      themeMode: themeMode ?? this.themeMode,
      backgroundUrl: backgroundUrl ?? this.backgroundUrl,
      onboardingCompleted: onboardingCompleted ?? this.onboardingCompleted,
      ageVerifiedAt: ageVerifiedAt ?? this.ageVerifiedAt,
      privacyPolicyVersion: privacyPolicyVersion ?? this.privacyPolicyVersion,
      cookiePreferences: cookiePreferences ?? this.cookiePreferences,
      interests: interests ?? this.interests,
      isAdmin: isAdmin,
      createdAt: createdAt,
    );
  }
}
