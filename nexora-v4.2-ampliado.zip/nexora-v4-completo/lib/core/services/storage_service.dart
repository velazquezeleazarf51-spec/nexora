import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';

/// Servicio de almacenamiento.
///
/// IMPORTANTE (seguridad):
/// - El bucket `media` actual es público → cualquiera con la URL puede descargar.
/// - Ocultar el botón "Descargar" NO protege el archivo.
/// - Para contenido restringido se debe usar un bucket privado + URLs firmadas.
/// - Este servicio prepara la vía de enlaces firmados. Migrar el contenido
///   sensible al bucket privado cuando se despliegue en producción.
class StorageService {
  StorageService(this._client);
  final SupabaseClient _client;

  static const privateMediaBucket = 'media-private';
  static const publicMediaBucket = 'media';
  static const gamesBucket = 'game-submissions';
  static const storiesBucket = 'stories';
  static const backgroundsBucket = 'backgrounds';

  /// URL pública (solo para contenido realmente público).
  String publicUrl(String bucket, String path) {
    return _client.storage.from(bucket).getPublicUrl(path);
  }

  /// URL firmada temporal para archivos privados.
  /// [expiresIn] en segundos (por defecto 1 hora).
  Future<String> signedUrl(
    String bucket,
    String path, {
    int expiresIn = 3600,
  }) async {
    return _client.storage.from(bucket).createSignedUrl(path, expiresIn);
  }

  /// Intenta obtener una URL usable para descarga respetando el permiso del post.
  /// Si el post no permite descarga, lanza excepción.
  Future<String> resolveDownloadUrl({
    required bool allowDownload,
    required String? mediaUrl,
    String? privatePath,
  }) async {
    if (!allowDownload) {
      throw Exception('El autor no permite la descarga de este contenido.');
    }
    if (mediaUrl == null || mediaUrl.isEmpty) {
      throw Exception('No hay archivo disponible para descargar.');
    }

    // Si tenemos ruta privada, preferir enlace firmado (15 min).
    if (privatePath != null && privatePath.isNotEmpty) {
      try {
        return await signedUrl(privateMediaBucket, privatePath, expiresIn: 900);
      } catch (_) {
        // Fallback controlado a la URL existente
      }
    }

    // Advertencia: URL pública. En producción migrar a bucket privado.
    return mediaUrl;
  }

  /// Sube bytes al bucket indicado bajo la carpeta del usuario autenticado.
  /// Si [usePrivate] es true, sube a media-private y devuelve el path (no URL pública).
  Future<String> uploadUserFile({
    required String bucket,
    required String fileName,
    required Uint8List bytes,
    required String contentType,
    bool usePrivate = false,
  }) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('No autenticado');

    final path = '$userId/${DateTime.now().millisecondsSinceEpoch}_$fileName';
    final targetBucket = usePrivate ? privateMediaBucket : bucket;

    await _client.storage.from(targetBucket).uploadBinary(
          path,
          bytes,
          fileOptions: FileOptions(contentType: contentType, upsert: false),
        );

    if (usePrivate) {
      return path;
    }
    return _client.storage.from(targetBucket).getPublicUrl(path);
  }
}
