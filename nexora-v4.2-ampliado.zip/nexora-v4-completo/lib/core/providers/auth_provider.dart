import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthState {
  const AuthState({this.isAdmin = false, this.user});
  final bool isAdmin;
  final User? user;
}

class AuthNotifier extends StateNotifier<AuthState> {
  AuthNotifier() : super(const AuthState()) { _refresh(); }

  Future<void> _refresh() async {
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      var admin = false;
      if (user != null) {
        final row = await client.from('profiles').select('is_admin').eq('id', user.id).maybeSingle();
        admin = row?['is_admin'] == true;
      }
      state = AuthState(isAdmin: admin, user: user);
    } catch (_) {
      state = const AuthState();
    }
  }

  Future<void> signOut() async {
    try { await Supabase.instance.client.auth.signOut(); } catch (_) {}
    state = const AuthState();
  }
}
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) => AuthNotifier());
