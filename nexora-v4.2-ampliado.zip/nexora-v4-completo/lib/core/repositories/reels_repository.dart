import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/post.dart';

/// Repositorio de videos cortos (Reels).
/// Estado: preparado. Falta integrar completamente reproducción vertical,
/// carga progresiva, reportes y pruebas de rendimiento.
class ReelsRepository {
  ReelsRepository(this._client);
  final SupabaseClient _client;

  /// Obtiene publicaciones marcadas como video corto, aprobadas, ordenadas por fecha.
  Future<List<Post>> fetchReels({int limit = 20, int offset = 0}) async {
    final response = await _client
        .from('posts')
        .select('''
          id, user_id, content, media_url, media_type, is_short_video,
          video_duration_seconds, category, download_enabled, downloadable_file_url,
          moderation_status, is_approved, likes_count, comments_count, created_at,
          profiles!posts_user_id_fkey (
            username, display_name, full_name, avatar_url, is_creator
          )
        ''')
        .eq('is_short_video', true)
        .eq('is_approved', true)
        .order('created_at', ascending: false)
        .range(offset, offset + limit - 1);

    return (response as List)
        .map((e) => Post.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> reportReel(String postId, String reason) async {
    // Placeholder: en producción insertar en tabla de reportes
    await _client.from('reports').insert({
      'target_type': 'post',
      'target_id': postId,
      'reason': reason,
      'reporter_id': _client.auth.currentUser?.id,
    });
  }
}
