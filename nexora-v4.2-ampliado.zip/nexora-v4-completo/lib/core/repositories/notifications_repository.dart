import 'package:supabase_flutter/supabase_flutter.dart';

class AppNotification {
  final String id;
  final String userId;
  final String type;
  final String? title;
  final String? body;
  final String? actorId;
  final String? targetType;
  final String? targetId;
  final bool isRead;
  final DateTime createdAt;
  final Map<String, dynamic>? data;

  const AppNotification({
    required this.id,
    required this.userId,
    required this.type,
    this.title,
    this.body,
    this.actorId,
    this.targetType,
    this.targetId,
    this.isRead = false,
    required this.createdAt,
    this.data,
  });

  factory AppNotification.fromMap(Map<String, dynamic> map) {
    return AppNotification(
      id: map['id'] as String,
      userId: map['user_id'] as String,
      type: map['type'] as String? ?? 'generic',
      title: map['title'] as String?,
      body: map['body'] as String? ?? map['message'] as String?,
      actorId: map['actor_id'] as String?,
      targetType: map['target_type'] as String?,
      targetId: map['target_id'] as String?,
      isRead: map['is_read'] == true || map['read'] == true,
      createdAt: DateTime.parse(map['created_at'].toString()),
      data: map['data'] as Map<String, dynamic>?,
    );
  }
}

/// Repositorio de notificaciones.
/// Estado: base preparada (Realtime + marcar leída).
/// Falta integrar la bandeja visual completa y generar todos los eventos
/// (seguidores, comentarios, mensajes, comunidades, revisión de juegos...).
class NotificationsRepository {
  NotificationsRepository(this._client);
  final SupabaseClient _client;

  Future<List<AppNotification>> fetchNotifications({int limit = 50}) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) return [];

    final response = await _client
        .from('notifications')
        .select()
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .limit(limit);

    return (response as List)
        .map((e) => AppNotification.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> markAsRead(String notificationId) async {
    await _client
        .from('notifications')
        .update({'is_read': true})
        .eq('id', notificationId);
  }

  Future<void> markAllAsRead() async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) return;

    await _client
        .from('notifications')
        .update({'is_read': true})
        .eq('user_id', userId)
        .eq('is_read', false);
  }

  /// Stream en tiempo real de la bandeja del usuario.
  Stream<List<AppNotification>> watchNotifications() {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) return const Stream.empty();

    return _client
        .from('notifications')
        .stream(primaryKey: ['id'])
        .eq('user_id', userId)
        .order('created_at', ascending: false)
        .map((rows) => rows
            .map((e) => AppNotification.fromMap(Map<String, dynamic>.from(e)))
            .toList());
  }
}
