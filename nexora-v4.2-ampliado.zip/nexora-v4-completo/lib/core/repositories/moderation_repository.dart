import 'package:supabase_flutter/supabase_flutter.dart';

/// Reportes y bloqueos.
/// La tabla `reports` está en schema_v6.
/// `blocks` se crea en schema_v7 si no existe.
class ModerationRepository {
  ModerationRepository(this._client);
  final SupabaseClient _client;

  String? get _uid => _client.auth.currentUser?.id;

  Future<void> report({
    required String targetType,
    required String targetId,
    required String reason,
  }) async {
    final uid = _uid;
    if (uid == null) throw Exception('No autenticado');
    await _client.from('reports').insert({
      'reporter_id': uid,
      'target_type': targetType,
      'target_id': targetId,
      'reason': reason,
    });
  }

  Future<void> blockUser(String targetUserId) async {
    final uid = _uid;
    if (uid == null) throw Exception('No autenticado');
    if (uid == targetUserId) throw Exception('No puedes bloquearte a ti mismo');
    await _client.from('blocks').insert({
      'blocker_id': uid,
      'blocked_id': targetUserId,
    });
  }

  Future<void> unblockUser(String targetUserId) async {
    final uid = _uid;
    if (uid == null) return;
    await _client
        .from('blocks')
        .delete()
        .eq('blocker_id', uid)
        .eq('blocked_id', targetUserId);
  }

  Future<bool> isBlocked(String targetUserId) async {
    final uid = _uid;
    if (uid == null) return false;
    final row = await _client
        .from('blocks')
        .select('blocker_id')
        .eq('blocker_id', uid)
        .eq('blocked_id', targetUserId)
        .maybeSingle();
    return row != null;
  }
}
