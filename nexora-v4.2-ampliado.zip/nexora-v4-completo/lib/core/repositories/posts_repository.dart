import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/post.dart';
import '../services/storage_service.dart';

/// Repositorio de publicaciones del feed.
class PostsRepository {
  PostsRepository(this._client) : _storage = StorageService(_client);
  final SupabaseClient _client;
  final StorageService _storage;

  Future<List<Post>> fetchFeed({int limit = 30, String? hashtag}) async {
    var query = _client.from('posts').select('''
      id, user_id, content, media_url, media_type, is_short_video,
      video_duration_seconds, category, download_enabled, allow_download,
      downloadable_file_url, moderation_status, is_approved,
      likes_count, comments_count, created_at, hashtags,
      profiles!posts_user_id_fkey (
        username, display_name, full_name, avatar_url, is_creator
      )
    ''').eq('is_approved', true);

    if (hashtag != null && hashtag.isNotEmpty) {
      query = query.contains('hashtags', [hashtag]);
    }

    final response = await query.order('created_at', ascending: false).limit(limit);

    return (response as List)
        .map((e) => Post.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> likePost(String postId) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('No autenticado');
    await _client.from('likes').insert({'post_id': postId, 'user_id': userId});
  }

  Future<void> unlikePost(String postId) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) return;
    await _client.from('likes').delete().eq('post_id', postId).eq('user_id', userId);
  }

  Future<void> savePost(String postId) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('No autenticado');
    await _client.from('saves').insert({'post_id': postId, 'user_id': userId});
  }

  Future<void> unsavePost(String postId) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) return;
    await _client.from('saves').delete().eq('post_id', postId).eq('user_id', userId);
  }

  Future<void> reportPost(String postId, String reason) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('No autenticado');
    await _client.from('reports').insert({
      'target_type': 'post',
      'target_id': postId,
      'reason': reason,
      'reporter_id': userId,
    });
  }

  /// Resuelve la URL de descarga respetando el permiso del autor.
  Future<String> getDownloadUrl(Post post) {
    final allowed = post.downloadEnabled;
    return _storage.resolveDownloadUrl(
      allowDownload: allowed,
      mediaUrl: post.downloadableFileUrl ?? post.mediaUrl,
    );
  }
}
