import 'package:supabase_flutter/supabase_flutter.dart';

class Community {
  final String id;
  final String name;
  final String? description;
  final String? coverUrl;
  final String ownerId;
  final bool isPrivate;
  final int membersCount;
  final DateTime createdAt;

  const Community({
    required this.id,
    required this.name,
    this.description,
    this.coverUrl,
    required this.ownerId,
    this.isPrivate = false,
    this.membersCount = 0,
    required this.createdAt,
  });

  factory Community.fromMap(Map<String, dynamic> map) {
    return Community(
      id: map['id'] as String,
      name: map['name'] as String,
      description: map['description'] as String?,
      coverUrl: map['cover_url'] as String?,
      ownerId: map['owner_id'] as String,
      isPrivate: map['is_private'] == true,
      membersCount: (map['members_count'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.parse(map['created_at'].toString()),
    );
  }
}

/// Repositorio de comunidades.
/// Estado: estructura y repositorio preparados.
/// Faltan pantallas de directorio, detalle, solicitudes, roles y moderación.
class CommunitiesRepository {
  CommunitiesRepository(this._client);
  final SupabaseClient _client;

  Future<List<Community>> fetchPublicCommunities({int limit = 30}) async {
    final response = await _client
        .from('communities')
        .select()
        .eq('is_private', false)
        .order('created_at', ascending: false)
        .limit(limit);

    return (response as List)
        .map((e) => Community.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<Community?> getCommunity(String id) async {
    final row = await _client.from('communities').select().eq('id', id).maybeSingle();
    if (row == null) return null;
    return Community.fromMap(Map<String, dynamic>.from(row));
  }

  /// Unirse a comunidad pública (membresía activa) o solicitar privada (pending).
  Future<void> joinOrRequest(String communityId, {required bool isPrivate}) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('No autenticado');

    await _client.from('community_members').insert({
      'community_id': communityId,
      'user_id': userId,
      'role': 'member',
      'status': isPrivate ? 'pending' : 'active',
    });
  }

  Future<List<Map<String, dynamic>>> fetchCommunityPosts(String communityId, {int limit = 20}) async {
    final response = await _client
        .from('community_posts')
        .select('*, posts(*)')
        .eq('community_id', communityId)
        .order('created_at', ascending: false)
        .limit(limit);
    return List<Map<String, dynamic>>.from(response as List);
  }

  Future<String> createCommunity({
    required String name,
    String? description,
    bool isPrivate = false,
  }) async {
    final userId = _client.auth.currentUser?.id;
    if (userId == null) throw Exception('No autenticado');

    final row = await _client
        .from('communities')
        .insert({
          'name': name,
          'description': description,
          'owner_id': userId,
          'is_private': isPrivate,
        })
        .select('id')
        .single();

    // El trigger SQL debería registrar al creador como propietario.
    return row['id'] as String;
  }
}
