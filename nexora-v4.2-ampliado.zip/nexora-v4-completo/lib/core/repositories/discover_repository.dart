import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/profile.dart';

/// Repositorio de búsqueda de personas y seguimiento.
/// Estado: lógica preparada. Falta pantalla completa de Explorar,
/// sugerencias y pruebas de seguridad (límites de abuso).
class DiscoverRepository {
  DiscoverRepository(this._client);
  final SupabaseClient _client;

  /// Busca perfiles por nombre de usuario o nombre visible.
  /// Requiere al menos 2 caracteres. Limita resultados.
  Future<List<Profile>> searchPeople(String query, {int limit = 20}) async {
    final q = query.trim();
    if (q.length < 2) return [];

    final response = await _client
        .from('profiles')
        .select()
        .or('username.ilike.%$q%,display_name.ilike.%$q%,full_name.ilike.%$q%')
        .limit(limit);

    return (response as List)
        .map((e) => Profile.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  /// Seguir a otro usuario. Impide auto-seguimiento.
  Future<void> follow(String targetUserId) async {
    final currentId = _client.auth.currentUser?.id;
    if (currentId == null) throw Exception('No autenticado');
    if (currentId == targetUserId) throw Exception('No puedes seguirte a ti mismo');

    await _client.from('follows').insert({
      'follower_id': currentId,
      'following_id': targetUserId,
    });
  }

  /// Dejar de seguir.
  Future<void> unfollow(String targetUserId) async {
    final currentId = _client.auth.currentUser?.id;
    if (currentId == null) throw Exception('No autenticado');

    await _client
        .from('follows')
        .delete()
        .eq('follower_id', currentId)
        .eq('following_id', targetUserId);
  }

  /// Comprueba si el usuario actual sigue a targetUserId.
  Future<bool> isFollowing(String targetUserId) async {
    final currentId = _client.auth.currentUser?.id;
    if (currentId == null) return false;

    final row = await _client
        .from('follows')
        .select('follower_id')
        .eq('follower_id', currentId)
        .eq('following_id', targetUserId)
        .maybeSingle();

    return row != null;
  }

  /// Sugerencias básicas (perfiles recientes de creadores).
  Future<List<Profile>> suggestedCreators({int limit = 10}) async {
    final response = await _client
        .from('profiles')
        .select()
        .eq('is_creator', true)
        .order('created_at', ascending: false)
        .limit(limit);

    return (response as List)
        .map((e) => Profile.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }
}
