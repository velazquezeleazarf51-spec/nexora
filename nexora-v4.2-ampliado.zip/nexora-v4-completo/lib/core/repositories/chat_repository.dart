import 'package:supabase_flutter/supabase_flutter.dart';

class ChatMessage {
  final String id;
  final String senderId;
  final String? receiverId;
  final String? content;
  final String? mediaUrl;
  final String? mediaType;
  final String? mediaName;
  final DateTime createdAt;

  const ChatMessage({
    required this.id,
    required this.senderId,
    this.receiverId,
    this.content,
    this.mediaUrl,
    this.mediaType,
    this.mediaName,
    required this.createdAt,
  });

  factory ChatMessage.fromMap(Map<String, dynamic> map) {
    return ChatMessage(
      id: map['id'] as String,
      senderId: map['sender_id'] as String,
      receiverId: map['receiver_id'] as String?,
      content: map['content'] as String?,
      mediaUrl: map['media_url'] as String?,
      mediaType: map['media_type'] as String?,
      mediaName: map['media_name'] as String?,
      createdAt: DateTime.parse(map['created_at'].toString()),
    );
  }

  bool isMine(String? myId) => senderId == myId;
}

class ConversationPreview {
  final String peerId;
  final String? peerName;
  final String? peerUsername;
  final String? peerAvatar;
  final String? lastMessage;
  final DateTime? lastAt;
  final bool lastFromMe;

  const ConversationPreview({
    required this.peerId,
    this.peerName,
    this.peerUsername,
    this.peerAvatar,
    this.lastMessage,
    this.lastAt,
    this.lastFromMe = false,
  });
}

/// Repositorio de chat 1:1.
/// Persistencia en `messages` + Realtime.
/// Pendiente: bloqueo, límites anti-spam, reportes desde el hilo y grupos.
class ChatRepository {
  ChatRepository(this._client);
  final SupabaseClient _client;

  String? get _uid => _client.auth.currentUser?.id;

  /// Lista conversaciones del usuario (último mensaje por interlocutor).
  Future<List<ConversationPreview>> fetchConversations() async {
    final uid = _uid;
    if (uid == null) return [];

    final response = await _client
        .from('messages')
        .select('id, sender_id, receiver_id, content, media_type, created_at')
        .or('sender_id.eq.$uid,receiver_id.eq.$uid')
        .order('created_at', ascending: false)
        .limit(200);

    final rows = List<Map<String, dynamic>>.from(response as List);
    final Map<String, Map<String, dynamic>> latestByPeer = {};

    for (final r in rows) {
      final sender = r['sender_id'] as String;
      final receiver = r['receiver_id'] as String?;
      if (receiver == null) continue;
      final peer = sender == uid ? receiver : sender;
      if (!latestByPeer.containsKey(peer)) {
        latestByPeer[peer] = r;
      }
    }

    if (latestByPeer.isEmpty) return [];

    final peerIds = latestByPeer.keys.toList();
    final profiles = await _client
        .from('profiles')
        .select('id, username, display_name, full_name, avatar_url')
        .inFilter('id', peerIds);

    final profileMap = {
      for (final p in profiles as List)
        (p as Map)['id'] as String: Map<String, dynamic>.from(p),
    };

    final list = <ConversationPreview>[];
    for (final entry in latestByPeer.entries) {
      final peerId = entry.key;
      final msg = entry.value;
      final prof = profileMap[peerId];
      final content = msg['content'] as String?;
      final mediaType = msg['media_type'] as String?;
      final preview = (content != null && content.isNotEmpty)
          ? content
          : (mediaType != null ? '📎 $mediaType' : 'Mensaje');

      list.add(ConversationPreview(
        peerId: peerId,
        peerName: prof?['display_name'] as String? ??
            prof?['full_name'] as String?,
        peerUsername: prof?['username'] as String?,
        peerAvatar: prof?['avatar_url'] as String?,
        lastMessage: preview,
        lastAt: DateTime.tryParse(msg['created_at'].toString()),
        lastFromMe: msg['sender_id'] == uid,
      ));
    }

    list.sort((a, b) {
      final aAt = a.lastAt ?? DateTime.fromMillisecondsSinceEpoch(0);
      final bAt = b.lastAt ?? DateTime.fromMillisecondsSinceEpoch(0);
      return bAt.compareTo(aAt);
    });
    return list;
  }

  /// Historial entre el usuario actual y [peerId].
  Future<List<ChatMessage>> fetchMessages(String peerId, {int limit = 80}) async {
    final uid = _uid;
    if (uid == null) return [];

    final response = await _client
        .from('messages')
        .select()
        .or(
          'and(sender_id.eq.$uid,receiver_id.eq.$peerId),'
          'and(sender_id.eq.$peerId,receiver_id.eq.$uid)',
        )
        .order('created_at', ascending: true)
        .limit(limit);

    return (response as List)
        .map((e) => ChatMessage.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  /// Stream Realtime de mensajes de la conversación con [peerId].
  Stream<List<ChatMessage>> watchMessages(String peerId) {
    final uid = _uid;
    if (uid == null) return const Stream.empty();

    // Realtime de la tabla; filtramos en cliente la pareja uid↔peerId.
    return _client
        .from('messages')
        .stream(primaryKey: ['id'])
        .order('created_at', ascending: true)
        .map((rows) {
      return rows
          .map((e) => ChatMessage.fromMap(Map<String, dynamic>.from(e)))
          .where((m) =>
              (m.senderId == uid && m.receiverId == peerId) ||
              (m.senderId == peerId && m.receiverId == uid))
          .toList();
    });
  }

  Future<ChatMessage> sendText({
    required String peerId,
    required String text,
  }) async {
    final uid = _uid;
    if (uid == null) throw Exception('No autenticado');
    if (uid == peerId) throw Exception('No puedes enviarte mensajes a ti mismo');
    final body = text.trim();
    if (body.isEmpty) throw Exception('Mensaje vacío');

    final row = await _client
        .from('messages')
        .insert({
          'sender_id': uid,
          'receiver_id': peerId,
          'content': body,
        })
        .select()
        .single();

    return ChatMessage.fromMap(Map<String, dynamic>.from(row));
  }

  Future<ChatMessage> sendMedia({
    required String peerId,
    required String mediaUrl,
    required String mediaType,
    String? mediaName,
    String? caption,
  }) async {
    final uid = _uid;
    if (uid == null) throw Exception('No autenticado');

    final row = await _client
        .from('messages')
        .insert({
          'sender_id': uid,
          'receiver_id': peerId,
          'content': caption,
          'media_url': mediaUrl,
          'media_type': mediaType,
          'media_name': mediaName,
        })
        .select()
        .single();

    return ChatMessage.fromMap(Map<String, dynamic>.from(row));
  }

  /// Busca usuarios para iniciar conversación.
  Future<List<Map<String, dynamic>>> searchUsers(String query, {int limit = 15}) async {
    final q = query.trim();
    if (q.length < 2) return [];
    final uid = _uid;

    final response = await _client
        .from('profiles')
        .select('id, username, display_name, full_name, avatar_url')
        .or('username.ilike.%$q%,display_name.ilike.%$q%,full_name.ilike.%$q%')
        .limit(limit);

    return (response as List)
        .map((e) => Map<String, dynamic>.from(e as Map))
        .where((e) => e['id'] != uid)
        .toList();
  }
}
