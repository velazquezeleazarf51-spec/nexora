/// Constantes de Nexora. Las credenciales de Supabase NUNCA deben ir hardcodeadas
/// en el código que se distribuye (APK). Usa .env o --dart-define.
class Constants {
  // Cargadas desde .env o dart-define en producción
  static String supabaseUrl = const String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '', // vacío = modo demo
  );
  static String supabaseAnonKey = const String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  static void configure({required String url, required String anonKey}) {
    supabaseUrl = url;
    supabaseAnonKey = anonKey;
  }

  /// true solo si hay URL y anon key válidas
  static bool get hasSupabaseCredentials =>
      supabaseUrl.isNotEmpty &&
      supabaseAnonKey.isNotEmpty &&
      supabaseUrl.startsWith('https://') &&
      supabaseAnonKey.length > 20;

  // Límites de producto
  static const int maxVideoDurationMinutes = 24;
  static const int maxStoryDurationSeconds = 60;
  static const int maxCaptionLength = 200;
  static const int maxPostTextLength = 2000;

  // Buckets de Storage
  static const String mediaBucket = 'media';
  static const String mediaPrivateBucket = 'media-private';
  static const String storiesBucket = 'stories';
  static const String gamesBucket = 'game-submissions';
  static const String backgroundsBucket = 'backgrounds';
}
