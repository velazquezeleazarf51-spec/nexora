import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

@immutable
class NexoraThemeState {
  const NexoraThemeState({this.darkMode = true, this.seedColor = const Color(0xFF8B7CF6)});
  final bool darkMode;
  final Color seedColor;
  NexoraThemeState copyWith({bool? darkMode, Color? seedColor}) =>
      NexoraThemeState(darkMode: darkMode ?? this.darkMode, seedColor: seedColor ?? this.seedColor);
}

final themeProvider = StateNotifierProvider<ThemeNotifier, NexoraThemeState>((ref) => ThemeNotifier());

class ThemeNotifier extends StateNotifier<NexoraThemeState> {
  ThemeNotifier() : super(const NexoraThemeState()) { _load(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final color = prefs.getInt('nexora_theme_color') ?? 0xFF8B7CF6;
    state = NexoraThemeState(
      darkMode: prefs.getBool('nexora_dark_mode') ?? true,
      seedColor: Color(color),
    );
  }

  Future<void> toggleDarkMode() async {
    state = state.copyWith(darkMode: !state.darkMode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('nexora_dark_mode', state.darkMode);
  }

  Future<void> setColor(Color color) async {
    state = state.copyWith(seedColor: color);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('nexora_theme_color', color.value);
  }

  Future<void> setDarkMode(bool value) async {
    state = state.copyWith(darkMode: value);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('nexora_dark_mode', value);
  }
}
