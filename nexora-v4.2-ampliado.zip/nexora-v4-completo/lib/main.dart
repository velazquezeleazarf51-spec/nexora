import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

import 'core/constants.dart';
import 'features/shell/root_gate.dart';
import 'theme/theme_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Carga .env si existe (desarrollo). En release usa --dart-define.
  try {
    await dotenv.load(fileName: '.env');
  } catch (_) {
    // .env opcional
  }

  final url = dotenv.env['SUPABASE_URL'] ?? Constants.supabaseUrl;
  final anon = dotenv.env['SUPABASE_ANON_KEY'] ?? Constants.supabaseAnonKey;
  Constants.configure(url: url, anonKey: anon);

  bool supabaseReady = false;
  if (url.isNotEmpty && anon.isNotEmpty) {
    try {
      await Supabase.initialize(url: url, anonKey: anon);
      supabaseReady = true;
    } catch (e) {
      debugPrint('Supabase init error: $e');
    }
  }

  runApp(
    ProviderScope(
      child: NexoraApp(supabaseReady: supabaseReady),
    ),
  );
}

class NexoraApp extends ConsumerWidget {
  const NexoraApp({super.key, required this.supabaseReady});
  final bool supabaseReady;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appearance = ref.watch(themeProvider);
    return MaterialApp(
      title: 'NEXORA',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: appearance.seedColor,
          brightness: Brightness.light,
        ),
        useMaterial3: true,
      ),
      darkTheme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: appearance.seedColor,
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      themeMode: appearance.darkMode ? ThemeMode.dark : ThemeMode.light,
      home: RootGate(supabaseReady: supabaseReady),
    );
  }
}
