import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/models/post.dart';
import '../../../core/repositories/reels_repository.dart';
import '../../../core/constants.dart';

/// Pantalla de Reels (videos cortos verticales).
/// Estado: interfaz básica preparada. Falta carga progresiva avanzada,
/// precarga de siguientes videos, controles de volumen/subtítulos,
/// reportes completos y optimización de memoria.
class ReelsScreen extends ConsumerStatefulWidget {
  const ReelsScreen({super.key});

  @override
  ConsumerState<ReelsScreen> createState() => _ReelsScreenState();
}

class _ReelsScreenState extends ConsumerState<ReelsScreen> {
  final PageController _pageController = PageController();
  List<Post> _reels = [];
  bool _loading = true;
  String? _error;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadReels();
  }

  Future<void> _loadReels() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() {
        _loading = false;
        _error = 'Modo demo: configura Supabase para ver Reels reales.';
      });
      return;
    }
    try {
      final repo = ReelsRepository(Supabase.instance.client);
      final list = await repo.fetchReels(limit: 15);
      if (mounted) {
        setState(() {
          _reels = list;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'No se pudieron cargar los Reels: $e';
        });
      }
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Colors.white))
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Iconsax.video_slash, size: 48, color: Colors.white54),
                        const SizedBox(height: 16),
                        Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                        const SizedBox(height: 16),
                        FilledButton(onPressed: _loadReels, child: const Text('Reintentar')),
                      ],
                    ),
                  ),
                )
              : _reels.isEmpty
                  ? const Center(
                      child: Text(
                        'Aún no hay Reels.\nSé el primero en publicar un video corto.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white70),
                      ),
                    )
                  : PageView.builder(
                      controller: _pageController,
                      scrollDirection: Axis.vertical,
                      itemCount: _reels.length,
                      onPageChanged: (i) => setState(() => _currentIndex = i),
                      itemBuilder: (context, index) {
                        return _ReelPage(
                          post: _reels[index],
                          isActive: index == _currentIndex,
                        );
                      },
                    ),
    );
  }
}

class _ReelPage extends StatefulWidget {
  const _ReelPage({required this.post, required this.isActive});
  final Post post;
  final bool isActive;

  @override
  State<_ReelPage> createState() => _ReelPageState();
}

class _ReelPageState extends State<_ReelPage> {
  VideoPlayerController? _controller;
  bool _initialized = false;

  @override
  void initState() {
    super.initState();
    _initPlayer();
  }

  @override
  void didUpdateWidget(covariant _ReelPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      _controller?.play();
    } else if (!widget.isActive && oldWidget.isActive) {
      _controller?.pause();
    }
  }

  Future<void> _initPlayer() async {
    final url = widget.post.mediaUrl;
    if (url == null || url.isEmpty) return;
    _controller = VideoPlayerController.networkUrl(Uri.parse(url));
    try {
      await _controller!.initialize();
      _controller!.setLooping(true);
      if (widget.isActive) await _controller!.play();
      if (mounted) setState(() => _initialized = true);
    } catch (_) {
      // Fallo de reproducción
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        if (_initialized && _controller != null)
          FittedBox(
            fit: BoxFit.cover,
            child: SizedBox(
              width: _controller!.value.size.width,
              height: _controller!.value.size.height,
              child: VideoPlayer(_controller!),
            ),
          )
        else
          Container(
            color: Colors.black87,
            child: const Center(child: CircularProgressIndicator(color: Colors.white54)),
          ),
        // Gradiente inferior para legibilidad
        Positioned(
          left: 0,
          right: 0,
          bottom: 0,
          height: 220,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.transparent, Colors.black.withValues(alpha: 0.75)],
              ),
            ),
          ),
        ),
        // Info del autor y acciones
        Positioned(
          left: 16,
          right: 80,
          bottom: 32,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '@${widget.post.authorUsername ?? widget.post.authorDisplayName ?? 'usuario'}',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
              ),
              if (widget.post.content != null && widget.post.content!.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  widget.post.content!,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
              ],
            ],
          ),
        ),
        // Botones laterales
        Positioned(
          right: 12,
          bottom: 100,
          child: Column(
            children: [
              _ActionButton(icon: Iconsax.heart, label: '${widget.post.likesCount}'),
              const SizedBox(height: 18),
              _ActionButton(icon: Iconsax.message, label: '${widget.post.commentsCount}'),
              const SizedBox(height: 18),
              _ActionButton(icon: Iconsax.share, label: 'Compartir'),
              const SizedBox(height: 18),
              if (widget.post.downloadEnabled)
                const _ActionButton(icon: Iconsax.document_download, label: 'Descargar'),
            ],
          ),
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 28),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 12)),
      ],
    );
  }
}
