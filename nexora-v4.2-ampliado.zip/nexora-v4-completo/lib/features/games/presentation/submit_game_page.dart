import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/constants.dart';

/// Formulario de envío de juegos HTML5/WebGL.
/// Estado: subida de paquete ZIP + inserción en estado pending.
/// Falta: validación profunda de contenido, análisis de seguridad del paquete
/// y ejecución aislada tras aprobación.
class SubmitGamePage extends StatefulWidget {
  const SubmitGamePage({super.key});

  @override
  State<SubmitGamePage> createState() => _SubmitGamePageState();
}

class _SubmitGamePageState extends State<SubmitGamePage> {
  final _formKey = GlobalKey<FormState>();
  final _titleCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _categoryCtrl = TextEditingController();
  PlatformFile? _package;
  PlatformFile? _cover;
  bool _offlineCompatible = false;
  bool _submitting = false;

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    _categoryCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickPackage() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['zip'],
      withData: kIsWeb,
    );
    if (result != null && result.files.isNotEmpty) {
      setState(() => _package = result.files.first);
    }
  }

  Future<void> _pickCover() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      withData: kIsWeb,
    );
    if (result != null && result.files.isNotEmpty) {
      setState(() => _cover = result.files.first);
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_package == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selecciona el paquete ZIP del juego.')),
      );
      return;
    }
    if (!Constants.hasSupabaseCredentials) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Supabase no configurado.')),
      );
      return;
    }

    setState(() => _submitting = true);
    final client = Supabase.instance.client;
    final userId = client.auth.currentUser?.id;
    if (userId == null) {
      setState(() => _submitting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Debes iniciar sesión para enviar un juego.')),
      );
      return;
    }

    try {
      final uuid = const Uuid().v4();
      final packagePath = '$userId/$uuid/${_package!.name}';

      // Subir paquete al bucket privado
      final bytes = _package!.bytes ??
          (kIsWeb ? null : await File(_package!.path!).readAsBytes());
      if (bytes == null) throw Exception('No se pudo leer el archivo del juego.');

      await client.storage.from('game-submissions').uploadBinary(
            packagePath,
            bytes,
            fileOptions: const FileOptions(contentType: 'application/zip', upsert: false),
          );

      String? coverUrl;
      if (_cover != null) {
        final coverPath = '$userId/$uuid/cover_${_cover!.name}';
        final coverBytes = _cover!.bytes ??
            (kIsWeb ? null : await File(_cover!.path!).readAsBytes());
        if (coverBytes != null) {
          await client.storage.from('game-submissions').uploadBinary(
                coverPath,
                coverBytes,
                fileOptions: FileOptions(
                  contentType: _cover!.extension == 'png' ? 'image/png' : 'image/jpeg',
                  upsert: false,
                ),
              );
          coverUrl = client.storage.from('game-submissions').getPublicUrl(coverPath);
        }
      }

      final packageUrl = client.storage.from('game-submissions').getPublicUrl(packagePath);

      await client.from('games').insert({
        'creator_id': userId,
        'title': _titleCtrl.text.trim(),
        'description': _descCtrl.text.trim(),
        'category': _categoryCtrl.text.trim().isEmpty ? null : _categoryCtrl.text.trim(),
        'package_url': packageUrl,
        'cover_url': coverUrl,
        'package_type': 'html5_zip',
        'offline_compatible': _offlineCompatible,
        'status': 'pending',
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Juego enviado correctamente. Quedará pendiente de revisión administrativa. '
              'No se publica automáticamente.',
            ),
            duration: Duration(seconds: 5),
          ),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al enviar: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Enviar un juego')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Text(
              'Solo se aceptan paquetes HTML5/WebGL en formato ZIP. '
              'No se ejecutan archivos EXE ni APK. El administrador revisará el contenido antes de publicarlo.',
            ),
            const SizedBox(height: 20),
            TextFormField(
              controller: _titleCtrl,
              decoration: const InputDecoration(
                labelText: 'Título *',
                border: OutlineInputBorder(),
              ),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'Obligatorio' : null,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _descCtrl,
              decoration: const InputDecoration(
                labelText: 'Descripción',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 14),
            TextFormField(
              controller: _categoryCtrl,
              decoration: const InputDecoration(
                labelText: 'Categoría (opcional)',
                border: OutlineInputBorder(),
                hintText: 'Puzzle, acción, educativo…',
              ),
            ),
            const SizedBox(height: 18),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Iconsax.document_upload),
              title: Text(_package?.name ?? 'Seleccionar paquete ZIP *'),
              subtitle: _package != null
                  ? Text('${(_package!.size / 1024 / 1024).toStringAsFixed(1)} MB')
                  : const Text('HTML5 o WebGL empaquetado'),
              trailing: OutlinedButton(onPressed: _pickPackage, child: const Text('Elegir')),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Iconsax.image),
              title: Text(_cover?.name ?? 'Imagen de portada (opcional)'),
              trailing: OutlinedButton(onPressed: _pickCover, child: const Text('Elegir')),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Compatible con uso sin conexión'),
              subtitle: const Text('Solo marca esta opción si el juego funciona localmente sin servidores externos.'),
              value: _offlineCompatible,
              onChanged: (v) => setState(() => _offlineCompatible = v),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _submitting ? null : _submit,
              icon: _submitting
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Iconsax.send_2),
              label: Text(_submitting ? 'Enviando…' : 'Enviar para revisión'),
            ),
            const SizedBox(height: 16),
            Text(
              'Importante: el envío queda en estado pendiente. Solo los juegos aprobados aparecen en la biblioteca pública. '
              'La descarga offline es manual y solo para juegos marcados como compatibles.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
