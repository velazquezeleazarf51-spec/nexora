import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/constants.dart';
import 'submit_game_page.dart';

/// Biblioteca pública de juegos aprobados.
/// Estado: consulta de juegos aprobados + acceso a envío.
/// Falta: reproducción aislada, descarga offline real, gestión de espacio y versiones.
class GamesLibraryScreen extends ConsumerStatefulWidget {
  const GamesLibraryScreen({super.key});

  @override
  ConsumerState<GamesLibraryScreen> createState() => _GamesLibraryScreenState();
}

class _GamesLibraryScreenState extends ConsumerState<GamesLibraryScreen> {
  List<Map<String, dynamic>> _games = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() {
        _loading = false;
        _error = 'Modo demo: configura Supabase para ver la biblioteca de juegos.';
      });
      return;
    }
    try {
      final response = await Supabase.instance.client
          .from('games')
          .select()
          .eq('status', 'approved')
          .order('created_at', ascending: false)
          .limit(40);

      if (mounted) {
        setState(() {
          _games = List<Map<String, dynamic>>.from(response as List);
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Error al cargar juegos: $e';
        });
      }
    }
  }

  Future<void> _openGame(Map<String, dynamic> game) async {
    final url = game['package_url'] as String? ?? game['game_url'] as String?;
    if (url == null || url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Este juego no tiene URL disponible.')),
      );
      return;
    }
    final uri = Uri.tryParse(url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No se pudo abrir el juego.')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Biblioteca de juegos'),
        actions: [
          IconButton(
            icon: const Icon(Iconsax.add_circle),
            tooltip: 'Enviar un juego',
            onPressed: () {
              if (!Constants.hasSupabaseCredentials) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Configura Supabase primero.')),
                );
                return;
              }
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SubmitGamePage()),
              ).then((_) => _load());
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(_error!, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        FilledButton(onPressed: _load, child: const Text('Reintentar')),
                      ],
                    ),
                  ),
                )
              : _games.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Iconsax.game, size: 56, color: theme.colorScheme.outline),
                          const SizedBox(height: 12),
                          const Text('Aún no hay juegos aprobados.'),
                          const SizedBox(height: 8),
                          const Text(
                            'Los creadores pueden enviar paquetes HTML5/WebGL.\n'
                            'Solo aparecen tras revisión administrativa.',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 16),
                          FilledButton.icon(
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(builder: (_) => const SubmitGamePage()),
                              );
                            },
                            icon: const Icon(Iconsax.add),
                            label: const Text('Enviar un juego'),
                          ),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: GridView.builder(
                        padding: const EdgeInsets.all(12),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.78,
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                        ),
                        itemCount: _games.length,
                        itemBuilder: (context, i) {
                          final g = _games[i];
                          final title = g['title'] as String? ?? 'Juego';
                          final cover = g['cover_url'] as String? ?? g['image_url'] as String?;
                          final offline = g['offline_compatible'] == true;
                          return Card(
                            clipBehavior: Clip.antiAlias,
                            child: InkWell(
                              onTap: () => _openGame(g),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  Expanded(
                                    child: cover != null
                                        ? Image.network(cover, fit: BoxFit.cover, errorBuilder: (_, __, ___) =>
                                            const Center(child: Icon(Iconsax.game, size: 40)))
                                        : const Center(child: Icon(Iconsax.game, size: 40)),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(title, maxLines: 2, overflow: TextOverflow.ellipsis,
                                            style: theme.textTheme.titleSmall),
                                        if (offline)
                                          Padding(
                                            padding: const EdgeInsets.only(top: 4),
                                            child: Text('Offline posible',
                                                style: theme.textTheme.labelSmall?.copyWith(
                                                  color: theme.colorScheme.primary,
                                                )),
                                          ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
    );
  }
}
