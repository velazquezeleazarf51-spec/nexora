import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';

import '../../../core/constants.dart';
import '../../../core/repositories/notifications_repository.dart';

/// Bandeja de notificaciones.
/// Estado: lectura + marcar como leída + stream preparado.
/// Falta: generación completa de eventos (likes, comentarios, mensajes,
/// comunidades, revisión de juegos) y notificaciones push del sistema.
class NotificationsScreen extends ConsumerStatefulWidget {
  const NotificationsScreen({super.key});

  @override
  ConsumerState<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends ConsumerState<NotificationsScreen> {
  List<AppNotification> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() {
        _loading = false;
        _error = 'Modo demo: configura Supabase para ver notificaciones.';
      });
      return;
    }
    try {
      final repo = NotificationsRepository(Supabase.instance.client);
      final list = await repo.fetchNotifications();
      if (mounted) {
        setState(() {
          _items = list;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Error: $e';
        });
      }
    }
  }

  Future<void> _markRead(AppNotification n) async {
    if (n.isRead) return;
    try {
      final repo = NotificationsRepository(Supabase.instance.client);
      await repo.markAsRead(n.id);
      setState(() {
        final idx = _items.indexWhere((e) => e.id == n.id);
        if (idx >= 0) {
          _items[idx] = AppNotification(
            id: n.id,
            userId: n.userId,
            type: n.type,
            title: n.title,
            body: n.body,
            actorId: n.actorId,
            targetType: n.targetType,
            targetId: n.targetId,
            isRead: true,
            createdAt: n.createdAt,
            data: n.data,
          );
        }
      });
    } catch (_) {}
  }

  Future<void> _markAll() async {
    try {
      final repo = NotificationsRepository(Supabase.instance.client);
      await repo.markAllAsRead();
      setState(() {
        _items = _items
            .map((n) => AppNotification(
                  id: n.id,
                  userId: n.userId,
                  type: n.type,
                  title: n.title,
                  body: n.body,
                  actorId: n.actorId,
                  targetType: n.targetType,
                  targetId: n.targetId,
                  isRead: true,
                  createdAt: n.createdAt,
                  data: n.data,
                ))
            .toList();
      });
    } catch (_) {}
  }

  IconData _iconFor(String type) {
    switch (type) {
      case 'follow':
        return Iconsax.user_add;
      case 'like':
        return Iconsax.heart;
      case 'comment':
        return Iconsax.message;
      case 'message':
        return Iconsax.messages_2;
      case 'community':
        return Iconsax.people;
      case 'game_review':
        return Iconsax.game;
      default:
        return Iconsax.notification;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Notificaciones'),
        actions: [
          if (_items.any((e) => !e.isRead))
            TextButton(onPressed: _markAll, child: const Text('Marcar todas')),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)))
              : _items.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Iconsax.notification, size: 48, color: theme.colorScheme.outline),
                          const SizedBox(height: 12),
                          const Text('No tienes notificaciones todavía.'),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        itemCount: _items.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (context, i) {
                          final n = _items[i];
                          final time = DateFormat('dd MMM · HH:mm').format(n.createdAt.toLocal());
                          return ListTile(
                            leading: CircleAvatar(
                              backgroundColor: n.isRead
                                  ? theme.colorScheme.surfaceContainerHighest
                                  : theme.colorScheme.primaryContainer,
                              child: Icon(_iconFor(n.type), size: 20),
                            ),
                            title: Text(
                              n.title ?? n.body ?? 'Notificación',
                              style: TextStyle(fontWeight: n.isRead ? FontWeight.normal : FontWeight.w600),
                            ),
                            subtitle: Text('$time · ${n.type}'),
                            trailing: n.isRead ? null : const Icon(Icons.circle, size: 10, color: Colors.blueAccent),
                            onTap: () => _markRead(n),
                          );
                        },
                      ),
                    ),
    );
  }
}
