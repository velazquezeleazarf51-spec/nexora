import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';

import '../../../core/constants.dart';
import '../../../core/repositories/chat_repository.dart';
import 'chat_room_screen.dart';

/// Lista de conversaciones + búsqueda para iniciar chat.
class ChatListScreen extends ConsumerStatefulWidget {
  const ChatListScreen({super.key});

  @override
  ConsumerState<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends ConsumerState<ChatListScreen> {
  List<ConversationPreview> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() {
        _loading = false;
        _error = 'Configura Supabase para usar el chat real.';
      });
      return;
    }
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() {
        _loading = false;
        _error = 'Inicia sesión para ver tus conversaciones.';
      });
      return;
    }
    try {
      final repo = ChatRepository(Supabase.instance.client);
      final list = await repo.fetchConversations();
      if (mounted) {
        setState(() {
          _items = list;
          _loading = false;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Error al cargar chats: $e';
        });
      }
    }
  }

  Future<void> _startNewChat() async {
    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => const _UserSearchSheet(),
    );
    if (result == null || !mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChatRoomScreen(
          peerId: result['id'] as String,
          peerName: result['display_name'] as String? ??
              result['full_name'] as String? ??
              result['username'] as String? ??
              'Usuario',
          peerAvatar: result['avatar_url'] as String?,
        ),
      ),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text('Mensajes', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                ),
                IconButton(
                  tooltip: 'Nuevo chat',
                  onPressed: _startNewChat,
                  icon: const Icon(Iconsax.message_add),
                ),
              ],
            ),
          ),
          Expanded(child: _buildBody(theme)),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _startNewChat,
        child: const Icon(Iconsax.edit),
      ),
    );
  }

  Widget _buildBody(ThemeData theme) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Iconsax.messages_2, size: 48, color: theme.colorScheme.outline),
              const SizedBox(height: 12),
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton(onPressed: _load, child: const Text('Reintentar')),
            ],
          ),
        ),
      );
    }
    if (_items.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Iconsax.messages_2, size: 56, color: theme.colorScheme.outline),
              const SizedBox(height: 12),
              const Text('Aún no tienes conversaciones.'),
              const SizedBox(height: 8),
              const Text('Busca a alguien para empezar a chatear.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: _startNewChat,
                icon: const Icon(Iconsax.message_add),
                label: const Text('Nuevo mensaje'),
              ),
            ],
          ),
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        itemCount: _items.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final c = _items[i];
          final name = c.peerName ?? c.peerUsername ?? 'Usuario';
          final time = c.lastAt != null
              ? DateFormat('dd/MM HH:mm').format(c.lastAt!.toLocal())
              : '';
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: c.peerAvatar != null ? NetworkImage(c.peerAvatar!) : null,
              child: c.peerAvatar == null
                  ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?')
                  : null,
            ),
            title: Text(name),
            subtitle: Text(
              '${c.lastFromMe ? "Tú: " : ""}${c.lastMessage ?? ""}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: Text(time, style: theme.textTheme.labelSmall),
            onTap: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => ChatRoomScreen(
                    peerId: c.peerId,
                    peerName: name,
                    peerAvatar: c.peerAvatar,
                  ),
                ),
              );
              _load();
            },
          );
        },
      ),
    );
  }
}

class _UserSearchSheet extends StatefulWidget {
  const _UserSearchSheet();

  @override
  State<_UserSearchSheet> createState() => _UserSearchSheetState();
}

class _UserSearchSheetState extends State<_UserSearchSheet> {
  final _ctrl = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  bool _loading = false;

  Future<void> _search(String q) async {
    if (q.trim().length < 2) {
      setState(() => _results = []);
      return;
    }
    setState(() => _loading = true);
    try {
      final repo = ChatRepository(Supabase.instance.client);
      final list = await repo.searchUsers(q);
      if (mounted) setState(() => _results = list);
    } catch (_) {
      if (mounted) setState(() => _results = []);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(16, 8, 16, 16 + bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Nuevo mensaje', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 12),
          TextField(
            controller: _ctrl,
            decoration: const InputDecoration(
              hintText: 'Buscar por nombre o usuario',
              prefixIcon: Icon(Iconsax.search_normal),
              border: OutlineInputBorder(),
            ),
            onChanged: _search,
            autofocus: true,
          ),
          const SizedBox(height: 12),
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_results.isEmpty && _ctrl.text.length >= 2)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Sin resultados'),
            )
          else
            Flexible(
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: _results.length,
                itemBuilder: (context, i) {
                  final u = _results[i];
                  final name = u['display_name'] as String? ??
                      u['full_name'] as String? ??
                      u['username'] as String? ??
                      'Usuario';
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: u['avatar_url'] != null
                          ? NetworkImage(u['avatar_url'] as String)
                          : null,
                      child: u['avatar_url'] == null
                          ? Text(name[0].toUpperCase())
                          : null,
                    ),
                    title: Text(name),
                    subtitle: u['username'] != null ? Text('@${u['username']}') : null,
                    onTap: () => Navigator.pop(context, u),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
