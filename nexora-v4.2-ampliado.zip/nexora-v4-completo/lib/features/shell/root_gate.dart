import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/constants.dart';
import '../home/home_screen.dart';
import '../onboarding/presentation/onboarding_screen.dart';
import '../auth/presentation/login_screen.dart';

/// Decide qué mostrar al arrancar:
/// - Sin credenciales Supabase → Home en modo demo
/// - Con sesión y onboarding incompleto → Onboarding
/// - En cualquier otro caso → Home
class RootGate extends ConsumerStatefulWidget {
  const RootGate({super.key, required this.supabaseReady});
  final bool supabaseReady;

  @override
  ConsumerState<RootGate> createState() => _RootGateState();
}

class _RootGateState extends ConsumerState<RootGate> {
  bool _checking = true;
  bool _needsOnboarding = false;
  bool _needsLogin = false;
  String _displayName = 'Usuario';
  late final StreamSubscription<AuthState>? _authSub;

  @override
  void initState() {
    super.initState();
    _evaluate();
    if (widget.supabaseReady && Constants.hasSupabaseCredentials) {
      _authSub = Supabase.instance.client.auth.onAuthStateChange.listen((data) {
        // Re-evaluar al iniciar/cerrar sesión para mostrar onboarding si aplica.
        _evaluate();
      });
    } else {
      _authSub = null;
    }
  }

  @override
  void dispose() {
    _authSub?.cancel();
    super.dispose();
  }

  Future<void> _evaluate() async {
    if (!widget.supabaseReady || !Constants.hasSupabaseCredentials) {
      setState(() {
        _checking = false;
        _needsOnboarding = false;
        _needsLogin = false;
      });
      return;
    }

    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;

      if (user == null) {
        // No forzamos login: la app puede usarse en demo / explorar UI.
        // El chat y otras funciones pedirán sesión cuando haga falta.
        setState(() {
          _checking = false;
          _needsLogin = false;
          _needsOnboarding = false;
        });
        return;
      }

      final row = await client
          .from('profiles')
          .select('onboarding_completed, display_name, full_name, username')
          .eq('id', user.id)
          .maybeSingle();

      final completed = row?['onboarding_completed'] == true;
      final name = row?['display_name'] as String? ??
          row?['full_name'] as String? ??
          row?['username'] as String? ??
          user.email?.split('@').first ??
          'Usuario';

      if (mounted) {
        setState(() {
          _displayName = name;
          _needsOnboarding = !completed;
          _checking = false;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          _checking = false;
          _needsOnboarding = false;
        });
      }
    }
  }

  void _onOnboardingDone() {
    setState(() => _needsOnboarding = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_checking) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_needsOnboarding) {
      return OnboardingScreen(onCompleted: _onOnboardingDone);
    }

    if (_needsLogin) {
      return LoginScreen(onSuccess: () {
        setState(() => _needsLogin = false);
        _evaluate();
      });
    }

    return HomeScreen(
      supabaseReady: widget.supabaseReady,
      isDemo: !widget.supabaseReady,
      displayName: _displayName,
    );
  }
}
