import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax/iconsax.dart';

import '../home/home_screen.dart';
import '../reels/presentation/reels_screen.dart';
import '../discover/presentation/discover_screen.dart';
import '../notifications/presentation/notifications_screen.dart';
import '../profile/presentation/profile_screen.dart';
import '../games/presentation/games_library_screen.dart';

/// Shell principal con navegación inferior.
/// Conserva la identidad visual de NEXORA y permite acceso rápido a
/// las secciones prioritarias.
class MainShell extends ConsumerStatefulWidget {
  const MainShell({
    super.key,
    required this.supabaseReady,
    this.isDemo = false,
    this.displayName = 'Usuario',
  });

  final bool supabaseReady;
  final bool isDemo;
  final String displayName;

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(
        supabaseReady: widget.supabaseReady,
        isDemo: widget.isDemo,
        displayName: widget.displayName,
      ),
      const ReelsScreen(),
      const DiscoverScreen(),
      const GamesLibraryScreen(),
      const NotificationsScreen(),
      ProfileScreen(displayName: widget.displayName),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(
            icon: Icon(Iconsax.home),
            selectedIcon: Icon(Iconsax.home_15),
            label: 'Inicio',
          ),
          NavigationDestination(
            icon: Icon(Iconsax.video_play),
            selectedIcon: Icon(Iconsax.video_play5),
            label: 'Reels',
          ),
          NavigationDestination(
            icon: Icon(Iconsax.search_normal),
            selectedIcon: Icon(Iconsax.search_normal_1),
            label: 'Explorar',
          ),
          NavigationDestination(
            icon: Icon(Iconsax.game),
            selectedIcon: Icon(Iconsax.game5),
            label: 'Juegos',
          ),
          NavigationDestination(
            icon: Icon(Iconsax.notification),
            selectedIcon: Icon(Iconsax.notification5),
            label: 'Avisos',
          ),
          NavigationDestination(
            icon: Icon(Iconsax.user),
            selectedIcon: Icon(Iconsax.user5),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }
}
