import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

import '../../core/constants.dart';

/// Preferencias de cookies / tecnologías similares.
/// Necesarias siempre activas; analíticas y marketing opcionales.
class CookieConsentPage extends StatefulWidget {
  const CookieConsentPage({super.key});

  @override
  State<CookieConsentPage> createState() => _CookieConsentPageState();
}

class _CookieConsentPageState extends State<CookieConsentPage> {
  bool _analytics = false;
  bool _marketing = false;
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _analytics = prefs.getBool('nexora_cookie_analytics') ?? false;
    _marketing = prefs.getBool('nexora_cookie_marketing') ?? false;

    if (Constants.hasSupabaseCredentials) {
      final user = Supabase.instance.client.auth.currentUser;
      if (user != null) {
        try {
          final row = await Supabase.instance.client
              .from('profiles')
              .select('cookie_preferences')
              .eq('id', user.id)
              .maybeSingle();
          final cp = row?['cookie_preferences'] as Map?;
          if (cp != null) {
            _analytics = cp['analytics'] == true;
            _marketing = cp['marketing'] == true;
          }
        } catch (_) {}
      }
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    setState(() => _saving = true);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('nexora_cookie_analytics', _analytics);
    await prefs.setBool('nexora_cookie_marketing', _marketing);
    await prefs.setBool('nexora_cookie_configured', true);

    if (Constants.hasSupabaseCredentials) {
      final user = Supabase.instance.client.auth.currentUser;
      if (user != null) {
        try {
          await Supabase.instance.client.from('profiles').update({
            'cookie_preferences': {
              'necessary': true,
              'analytics': _analytics,
              'marketing': _marketing,
            },
          }).eq('id', user.id);
        } catch (_) {}
      }
    }

    if (mounted) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Preferencias de cookies guardadas')),
      );
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cookies y privacidad')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Icon(Iconsax.shield_tick, size: 40),
                const SizedBox(height: 12),
                Text(
                  'NEXORA distingue cookies estrictamente necesarias de las opcionales.',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 8),
                const Text(
                  'Las necesarias permiten iniciar sesión y recordar preferencias básicas. '
                  'Las analíticas y de marketing solo se activan con tu consentimiento. '
                  'En Android también pueden existir identificadores de SDK distintos de cookies web.',
                ),
                const SizedBox(height: 20),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Necesarias'),
                  subtitle: const Text('Siempre activas. No se pueden desactivar.'),
                  value: true,
                  onChanged: null,
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Analíticas'),
                  subtitle: const Text('Ayudan a entender el uso de la app (opcional).'),
                  value: _analytics,
                  onChanged: (v) => setState(() => _analytics = v),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Marketing'),
                  subtitle: const Text('Personalización comercial (opcional).'),
                  value: _marketing,
                  onChanged: (v) => setState(() => _marketing = v),
                ),
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: _saving ? null : _save,
                  child: Text(_saving ? 'Guardando…' : 'Guardar preferencias'),
                ),
                const SizedBox(height: 12),
                Text(
                  'La política de privacidad definitiva debe revisarse legalmente antes del lanzamiento.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
    );
  }
}
