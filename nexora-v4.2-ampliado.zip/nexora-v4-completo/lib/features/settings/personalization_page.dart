import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../theme/theme_provider.dart';

class PersonalizationPage extends ConsumerStatefulWidget {
  const PersonalizationPage({super.key});
  @override
  ConsumerState<PersonalizationPage> createState() => _PersonalizationPageState();
}
class _PersonalizationPageState extends ConsumerState<PersonalizationPage> {
  final _hex = TextEditingController();
  static const _colors = <Color>[
    Color(0xFF8B7CF6), Color(0xFF2196F3), Color(0xFF009688),
    Color(0xFFE91E63), Color(0xFFFF9800), Color(0xFF4CAF50),
    Color(0xFF9C27B0), Color(0xFF607D8B), Color(0xFF795548),
  ];
  @override
  void dispose() { _hex.dispose(); super.dispose(); }

  void _applyHex() {
    var value = _hex.text.trim().replaceAll('#', '');
    if (value.length == 6) value = 'FF$value';
    final parsed = int.tryParse(value, radix: 16);
    if (parsed == null || value.length != 8) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Escribe un color hexadecimal válido, por ejemplo #7C4DFF.')));
      return;
    }
    ref.read(themeProvider.notifier).setColor(Color(parsed));
  }

  @override
  Widget build(BuildContext context) {
    final value = ref.watch(themeProvider);
    final notifier = ref.read(themeProvider.notifier);
    return Scaffold(
      appBar: AppBar(title: const Text('Personalización')),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Text('Apariencia', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Modo oscuro'),
          subtitle: const Text('Cambia entre modo claro y oscuro sin alterar el estilo de NEXORA.'),
          value: value.darkMode,
          onChanged: notifier.setDarkMode,
        ),
        const SizedBox(height: 18),
        Text('Color principal', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 6),
        const Text('Elige un color para botones, iconos y elementos destacados. Las animaciones y la estructura permanecen iguales.'),
        const SizedBox(height: 14),
        Wrap(spacing: 14, runSpacing: 14, children: [
          for (final color in _colors)
            InkWell(
              onTap: () => notifier.setColor(color),
              borderRadius: BorderRadius.circular(30),
              child: CircleAvatar(
                radius: 23, backgroundColor: color,
                child: value.seedColor.value == color.value ? const Icon(Icons.check, color: Colors.white) : null,
              ),
            ),
        ]),
        const SizedBox(height: 18),
        Text('Usar cualquier color', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextField(controller: _hex, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Código HEX', hintText: '#7C4DFF', border: OutlineInputBorder()))),
          const SizedBox(width: 8),
          FilledButton(onPressed: _applyHex, child: const Text('Aplicar')),
        ]),
        const SizedBox(height: 24),
        const Divider(),
        Text('Fondos personalizados', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 6),
        const Text('La carga y aplicación de imágenes propias como fondo queda pendiente de integrar con almacenamiento local y validación de archivos.'),
        const SizedBox(height: 20),
        const ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.lock_outline),
          title: Text('Identidad interna protegida'),
          subtitle: Text('El nombre, icono, estructura y animaciones originales de NEXORA no se modifican desde aquí.'),
        ),
      ]),
    );
  }
}
