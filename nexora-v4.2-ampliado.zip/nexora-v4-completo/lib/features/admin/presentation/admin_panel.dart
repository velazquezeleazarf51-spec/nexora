import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/constants.dart';
import '../../../core/providers/auth_provider.dart';

/// Panel básico de administración.
/// Estado: revisión de juegos (aprobar/rechazar) preparada.
/// Falta: reportes, moderación de publicaciones, suspensiones,
/// auditoría de acciones y confirmaciones adicionales.
class AdminPanel extends ConsumerStatefulWidget {
  const AdminPanel({super.key});

  @override
  ConsumerState<AdminPanel> createState() => _AdminPanelState();
}

class _AdminPanelState extends ConsumerState<AdminPanel> with SingleTickerProviderStateMixin {
  late TabController _tabs;
  List<Map<String, dynamic>> _pendingGames = [];
  bool _loadingGames = true;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _loadPendingGames();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _loadPendingGames() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() => _loadingGames = false);
      return;
    }
    try {
      final response = await Supabase.instance.client
          .from('games')
          .select()
          .eq('status', 'pending')
          .order('created_at', ascending: true);

      if (mounted) {
        setState(() {
          _pendingGames = List<Map<String, dynamic>>.from(response as List);
          _loadingGames = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _loadingGames = false);
    }
  }

  Future<void> _reviewGame(String id, String status) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(status == 'approved' ? 'Aprobar juego' : 'Rechazar juego'),
        content: Text(
          status == 'approved'
              ? 'El juego pasará a la biblioteca pública.'
              : 'El juego no se publicará. Puedes añadir una nota después si se implementa.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirmar')),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      await Supabase.instance.client.from('games').update({
        'status': status,
        'reviewed_by': userId,
        'reviewed_at': DateTime.now().toIso8601String(),
      }).eq('id', id);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(status == 'approved' ? 'Juego aprobado' : 'Juego rechazado')),
        );
        _loadPendingGames();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authProvider);
    if (!auth.isAdmin) {
      return Scaffold(
        appBar: AppBar(title: const Text('Administración')),
        body: const Center(
          child: Text('No tienes permisos de administrador.'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Panel de administración'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const [
            Tab(text: 'Juegos pendientes', icon: Icon(Iconsax.game)),
            Tab(text: 'Moderación', icon: Icon(Iconsax.shield_tick)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          // Juegos
          _loadingGames
              ? const Center(child: CircularProgressIndicator())
              : _pendingGames.isEmpty
                  ? const Center(child: Text('No hay juegos pendientes de revisión.'))
                  : ListView.builder(
                      itemCount: _pendingGames.length,
                      itemBuilder: (context, i) {
                        final g = _pendingGames[i];
                        return Card(
                          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          child: ListTile(
                            title: Text(g['title'] as String? ?? 'Sin título'),
                            subtitle: Text(
                              '${g['category'] ?? "Sin categoría"}\n'
                              '${g['description'] ?? ""}\n'
                              'Offline: ${g['offline_compatible'] == true ? "Sí" : "No"}',
                            ),
                            isThreeLine: true,
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.check_circle, color: Colors.green),
                                  tooltip: 'Aprobar',
                                  onPressed: () => _reviewGame(g['id'] as String, 'approved'),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.cancel, color: Colors.red),
                                  tooltip: 'Rechazar',
                                  onPressed: () => _reviewGame(g['id'] as String, 'rejected'),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
          // Moderación placeholder
          ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const ListTile(
                leading: Icon(Iconsax.flag),
                title: Text('Reportes'),
                subtitle: Text('Pendiente: listar y resolver reportes de usuarios.'),
              ),
              const ListTile(
                leading: Icon(Iconsax.trash),
                title: Text('Moderar publicaciones'),
                subtitle: Text('Pendiente: ocultar/eliminar contenido y aplicar sanciones.'),
              ),
              const ListTile(
                leading: Icon(Iconsax.user_remove),
                title: Text('Suspensiones'),
                subtitle: Text('Pendiente: gestión de cuentas y auditoría de acciones.'),
              ),
              const SizedBox(height: 16),
              Text(
                'Las operaciones sensibles deben validarse siempre en el servidor. '
                'Nunca incluyas la clave service_role en la aplicación cliente.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
