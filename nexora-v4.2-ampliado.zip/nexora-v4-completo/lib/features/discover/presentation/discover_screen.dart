import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/constants.dart';
import '../../../core/models/profile.dart';
import '../../../core/repositories/discover_repository.dart';
import '../../../core/repositories/moderation_repository.dart';
import '../../chat/presentation/chat_room_screen.dart';

/// Pantalla de Explorar / búsqueda de personas.
/// Estado: funcionalidad básica de búsqueda y seguimiento preparada.
/// Falta: sugerencias avanzadas, filtros, bloqueo/denuncia desde resultados.
class DiscoverScreen extends ConsumerStatefulWidget {
  const DiscoverScreen({super.key});

  @override
  ConsumerState<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends ConsumerState<DiscoverScreen> {
  final _controller = TextEditingController();
  List<Profile> _results = [];
  List<Profile> _suggestions = [];
  bool _loading = false;
  bool _loadingSuggestions = true;
  String? _error;
  final Map<String, bool> _following = {};

  @override
  void initState() {
    super.initState();
    _loadSuggestions();
  }

  Future<void> _loadSuggestions() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() => _loadingSuggestions = false);
      return;
    }
    try {
      final repo = DiscoverRepository(Supabase.instance.client);
      final list = await repo.suggestedCreators(limit: 12);
      if (mounted) {
        setState(() {
          _suggestions = list;
          _loadingSuggestions = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingSuggestions = false);
    }
  }

  Future<void> _search(String query) async {
    if (query.trim().length < 2) {
      setState(() {
        _results = [];
        _error = null;
      });
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final repo = DiscoverRepository(Supabase.instance.client);
      final list = await repo.searchPeople(query);
      if (mounted) {
        setState(() {
          _results = list;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = 'Error al buscar: $e';
        });
      }
    }
  }

  Future<void> _toggleFollow(Profile p) async {
    if (!Constants.hasSupabaseCredentials) return;
    final repo = DiscoverRepository(Supabase.instance.client);
    final isFollowing = _following[p.id] ?? false;
    try {
      if (isFollowing) {
        await repo.unfollow(p.id);
      } else {
        await repo.follow(p.id);
      }
      if (mounted) {
        setState(() => _following[p.id] = !isFollowing);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No se pudo actualizar el seguimiento: $e')),
        );
      }
    }
  }

  Future<void> _report(Profile p) async {
    final reasonCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Denunciar usuario'),
        content: TextField(
          controller: reasonCtrl,
          decoration: const InputDecoration(
            labelText: 'Motivo',
            border: OutlineInputBorder(),
          ),
          maxLines: 3,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enviar')),
        ],
      ),
    );
    if (ok != true || reasonCtrl.text.trim().isEmpty) return;
    try {
      await ModerationRepository(Supabase.instance.client).report(
        targetType: 'user',
        targetId: p.id,
        reason: reasonCtrl.text.trim(),
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Reporte enviado. Gracias.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  Future<void> _block(Profile p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Bloquear usuario'),
        content: Text('¿Bloquear a ${p.displayName ?? p.username ?? "este usuario"}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Bloquear')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ModerationRepository(Supabase.instance.client).blockUser(p.id);
      if (mounted) {
        setState(() {
          _results.removeWhere((e) => e.id == p.id);
          _suggestions.removeWhere((e) => e.id == p.id);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Usuario bloqueado')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  void _openChat(Profile p) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ChatRoomScreen(
          peerId: p.id,
          peerName: p.displayName ?? p.username ?? 'Usuario',
          peerAvatar: p.avatarUrl,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Explorar'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                hintText: 'Buscar personas (mín. 2 caracteres)',
                prefixIcon: const Icon(Iconsax.search_normal),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                filled: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              ),
              onChanged: _search,
              textInputAction: TextInputAction.search,
            ),
          ),
        ),
      ),
      body: _buildBody(theme),
    );
  }

  Widget _buildBody(ThemeData theme) {
    if (_controller.text.trim().length >= 2) {
      if (_loading) return const Center(child: CircularProgressIndicator());
      if (_error != null) {
        return Center(child: Text(_error!, style: TextStyle(color: theme.colorScheme.error)));
      }
      if (_results.isEmpty) {
        return const Center(child: Text('No se encontraron personas.'));
      }
      return ListView.builder(
        itemCount: _results.length,
        itemBuilder: (context, i) => _PersonTile(
          profile: _results[i],
          isFollowing: _following[_results[i].id] ?? false,
          onFollowToggle: () => _toggleFollow(_results[i]),
          onMessage: () => _openChat(_results[i]),
          onReport: () => _report(_results[i]),
          onBlock: () => _block(_results[i]),
        ),
      );
    }

    // Vista de sugerencias
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text('Creadores sugeridos', style: theme.textTheme.titleMedium),
        const SizedBox(height: 12),
        if (_loadingSuggestions)
          const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator()))
        else if (_suggestions.isEmpty)
          const Text('Configura Supabase o espera a que haya creadores.')
        else
          ..._suggestions.map((p) => _PersonTile(
                profile: p,
                isFollowing: _following[p.id] ?? false,
                onFollowToggle: () => _toggleFollow(p),
                onMessage: () => _openChat(p),
                onReport: () => _report(p),
                onBlock: () => _block(p),
              )),
        const SizedBox(height: 24),
        Text(
          'La búsqueda limita resultados. Puedes seguir, escribir, denunciar o bloquear desde el menú de cada persona.',
          style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
        ),
      ],
    );
  }
}

class _PersonTile extends StatelessWidget {
  const _PersonTile({
    required this.profile,
    required this.isFollowing,
    required this.onFollowToggle,
    required this.onMessage,
    required this.onReport,
    required this.onBlock,
  });
  final Profile profile;
  final bool isFollowing;
  final VoidCallback onFollowToggle;
  final VoidCallback onMessage;
  final VoidCallback onReport;
  final VoidCallback onBlock;

  @override
  Widget build(BuildContext context) {
    final name = profile.displayName ?? profile.username ?? 'Usuario';
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: profile.avatarUrl != null ? NetworkImage(profile.avatarUrl!) : null,
        child: profile.avatarUrl == null ? Text(name.isNotEmpty ? name[0].toUpperCase() : '?') : null,
      ),
      title: Text(name),
      subtitle: profile.username != null ? Text('@${profile.username}') : null,
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          FilledButton.tonal(
            onPressed: onFollowToggle,
            child: Text(isFollowing ? 'Siguiendo' : 'Seguir'),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              switch (v) {
                case 'message':
                  onMessage();
                case 'report':
                  onReport();
                case 'block':
                  onBlock();
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'message', child: Text('Mensaje')),
              PopupMenuItem(value: 'report', child: Text('Denunciar')),
              PopupMenuItem(value: 'block', child: Text('Bloquear')),
            ],
          ),
        ],
      ),
    );
  }
}
