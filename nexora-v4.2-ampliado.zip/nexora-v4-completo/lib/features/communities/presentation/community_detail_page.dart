import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/constants.dart';
import '../../../core/repositories/communities_repository.dart';

class CommunityDetailPage extends StatefulWidget {
  const CommunityDetailPage({super.key, required this.communityId});
  final String communityId;

  @override
  State<CommunityDetailPage> createState() => _CommunityDetailPageState();
}

class _CommunityDetailPageState extends State<CommunityDetailPage> {
  Community? _community;
  List<Map<String, dynamic>> _posts = [];
  bool _loading = true;
  String? _error;
  bool _joining = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() {
        _loading = false;
        _error = 'Configura Supabase.';
      });
      return;
    }
    try {
      final repo = CommunitiesRepository(Supabase.instance.client);
      final c = await repo.getCommunity(widget.communityId);
      final posts = await repo.fetchCommunityPosts(widget.communityId);
      if (mounted) {
        setState(() {
          _community = c;
          _posts = posts;
          _loading = false;
          if (c == null) _error = 'Comunidad no encontrada.';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = '$e';
        });
      }
    }
  }

  Future<void> _join() async {
    if (_community == null) return;
    setState(() => _joining = true);
    try {
      final repo = CommunitiesRepository(Supabase.instance.client);
      await repo.joinOrRequest(_community!.id, isPrivate: _community!.isPrivate);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              _community!.isPrivate
                  ? 'Solicitud enviada.'
                  : 'Te has unido a la comunidad.',
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(_community?.name ?? 'Comunidad')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Row(
                      children: [
                        CircleAvatar(
                          radius: 28,
                          child: Text(
                            _community!.name.isNotEmpty
                                ? _community!.name[0].toUpperCase()
                                : '?',
                            style: const TextStyle(fontSize: 22),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_community!.name, style: theme.textTheme.titleLarge),
                              Text(
                                _community!.isPrivate ? 'Privada' : 'Pública',
                                style: theme.textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                        FilledButton(
                          onPressed: _joining ? null : _join,
                          child: Text(
                            _community!.isPrivate ? 'Solicitar' : 'Unirse',
                          ),
                        ),
                      ],
                    ),
                    if (_community!.description != null) ...[
                      const SizedBox(height: 16),
                      Text(_community!.description!),
                    ],
                    const SizedBox(height: 20),
                    Text('Publicaciones', style: theme.textTheme.titleMedium),
                    const SizedBox(height: 8),
                    if (_posts.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 24),
                        child: Text('Aún no hay publicaciones en esta comunidad.'),
                      )
                    else
                      ..._posts.map((p) {
                        final post = p['posts'] as Map?;
                        return Card(
                          child: ListTile(
                            leading: const Icon(Iconsax.document_text),
                            title: Text(
                              post?['content']?.toString() ?? 'Publicación',
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(p['created_at']?.toString() ?? ''),
                          ),
                        );
                      }),
                    const SizedBox(height: 16),
                    Text(
                      'Roles, moderación de miembros y solicitudes pendientes se completarán en el panel de comunidad.',
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
    );
  }
}
