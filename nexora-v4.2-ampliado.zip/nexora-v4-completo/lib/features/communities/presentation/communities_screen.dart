import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/constants.dart';
import '../../../core/repositories/communities_repository.dart';
import 'community_detail_page.dart';

/// Directorio de comunidades.
/// Estado: listado público + creación básica + unirse/solicitar.
/// Falta: detalle completo, miembros, roles, moderación y solicitudes pendientes.
class CommunitiesScreen extends ConsumerStatefulWidget {
  const CommunitiesScreen({super.key});

  @override
  ConsumerState<CommunitiesScreen> createState() => _CommunitiesScreenState();
}

class _CommunitiesScreenState extends ConsumerState<CommunitiesScreen> {
  List<Community> _items = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() {
        _loading = false;
        _error = 'Modo demo: configura Supabase.';
      });
      return;
    }
    try {
      final repo = CommunitiesRepository(Supabase.instance.client);
      final list = await repo.fetchPublicCommunities();
      if (mounted) {
        setState(() {
          _items = list;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = '$e';
        });
      }
    }
  }

  Future<void> _createCommunity() async {
    final nameCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    bool isPrivate = false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Nueva comunidad'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Nombre *')),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Descripción')),
              SwitchListTile(
                title: const Text('Privada'),
                subtitle: const Text('Requiere aprobación de solicitud'),
                value: isPrivate,
                onChanged: (v) => setLocal(() => isPrivate = v),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Crear')),
          ],
        ),
      ),
    );

    if (ok != true || nameCtrl.text.trim().isEmpty) return;

    try {
      final repo = CommunitiesRepository(Supabase.instance.client);
      await repo.createCommunity(
        name: nameCtrl.text.trim(),
        description: descCtrl.text.trim().isEmpty ? null : descCtrl.text.trim(),
        isPrivate: isPrivate,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Comunidad creada. Eres el propietario.')),
        );
        _load();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  Future<void> _join(Community c) async {
    try {
      final repo = CommunitiesRepository(Supabase.instance.client);
      await repo.joinOrRequest(c.id, isPrivate: c.isPrivate);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(c.isPrivate
                ? 'Solicitud enviada. Espera aprobación.'
                : 'Te has unido a la comunidad.'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Comunidades'),
        actions: [
          IconButton(icon: const Icon(Iconsax.add), onPressed: _createCommunity),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text(_error!))
              : _items.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Iconsax.people, size: 48),
                          const SizedBox(height: 12),
                          const Text('No hay comunidades públicas todavía.'),
                          const SizedBox(height: 12),
                          FilledButton(onPressed: _createCommunity, child: const Text('Crear la primera')),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.builder(
                        itemCount: _items.length,
                        itemBuilder: (context, i) {
                          final c = _items[i];
                          return ListTile(
                            leading: CircleAvatar(
                              child: Text(c.name.isNotEmpty ? c.name[0].toUpperCase() : '?'),
                            ),
                            title: Text(c.name),
                            subtitle: Text(
                              '${c.isPrivate ? "Privada" : "Pública"} · ${c.membersCount} miembros'
                              '${c.description != null ? " · ${c.description}" : ""}',
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: OutlinedButton(
                              onPressed: () => _join(c),
                              child: Text(c.isPrivate ? 'Solicitar' : 'Unirse'),
                            ),
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => CommunityDetailPage(communityId: c.id),
                                ),
                              );
                            },
                          );
                        },
                      ),
                    ),
    );
  }
}
