import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax/iconsax.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/constants.dart';
import '../../../core/providers/auth_provider.dart';
import '../../settings/personalization_page.dart';
import '../../settings/cookie_consent_page.dart';
import '../../auth/presentation/login_screen.dart';
import '../../games/presentation/submit_game_page.dart';
import '../../admin/presentation/admin_panel.dart';
import '../../communities/presentation/communities_screen.dart';
import 'edit_profile_page.dart';

/// Perfil del usuario actual + acceso a configuración y funciones de creador.
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key, this.displayName = 'Usuario'});
  final String displayName;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final user = auth.user;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Perfil'),
        actions: [
          IconButton(
            icon: const Icon(Iconsax.setting_2),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const PersonalizationPage()),
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // Cabecera
          Row(
            children: [
              CircleAvatar(
                radius: 36,
                child: Text(
                  (user?.email ?? displayName).isNotEmpty
                      ? (user?.email ?? displayName)[0].toUpperCase()
                      : '?',
                  style: const TextStyle(fontSize: 28),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      user?.email ?? displayName,
                      style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    if (user != null)
                      Text(
                        'ID: ${user.id.substring(0, 8)}…',
                        style: theme.textTheme.bodySmall,
                      ),
                    if (auth.isAdmin)
                      Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Chip(
                          label: const Text('Administrador'),
                          visualDensity: VisualDensity.compact,
                          backgroundColor: theme.colorScheme.primaryContainer,
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Divider(),

          // Acciones principales
          _SectionTitle('Cuenta'),
          ListTile(
            leading: const Icon(Iconsax.user_edit),
            title: const Text('Editar perfil y portafolio'),
            subtitle: const Text('Nombre, bio, perfil de creador'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const EditProfilePage()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.colorfilter),
            title: const Text('Personalización'),
            subtitle: const Text('Color principal y modo claro/oscuro'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const PersonalizationPage()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.shield_tick),
            title: const Text('Cookies y privacidad'),
            subtitle: const Text('Preferencias de cookies opcionales'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CookieConsentPage()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.people),
            title: const Text('Comunidades'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CommunitiesScreen()),
              );
            },
          ),

          const SizedBox(height: 12),
          _SectionTitle('Creador'),
          ListTile(
            leading: const Icon(Iconsax.game),
            title: const Text('Enviar un juego'),
            subtitle: const Text('HTML5 / WebGL para revisión administrativa'),
            onTap: () {
              if (!Constants.hasSupabaseCredentials) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Configura Supabase primero.')),
                );
                return;
              }
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SubmitGamePage()),
              );
            },
          ),
          ListTile(
            leading: const Icon(Iconsax.heart),
            title: const Text('Donaciones recibidas'),
            subtitle: const Text('Historial (requiere proveedor de pagos)'),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                    'Las donaciones reales requieren proveedor externo, webhooks y cuenta comercial. '
                    'La tabla donation_events ya existe, pero no procesa pagos por sí sola.',
                  ),
                  duration: Duration(seconds: 5),
                ),
              );
            },
          ),

          if (auth.isAdmin) ...[
            const SizedBox(height: 12),
            _SectionTitle('Administración'),
            ListTile(
              leading: const Icon(Iconsax.shield_tick),
              title: const Text('Panel de administración'),
              subtitle: const Text('Juegos, reportes y moderación'),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const AdminPanel()),
                );
              },
            ),
          ],

          const SizedBox(height: 12),
          _SectionTitle('Sesión'),
          if (user == null)
            ListTile(
              leading: const Icon(Iconsax.login),
              title: const Text('Iniciar sesión / Registrarse'),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              },
            )
          else
            ListTile(
              leading: const Icon(Iconsax.logout),
              title: const Text('Cerrar sesión'),
              onTap: () async {
                await ref.read(authProvider.notifier).signOut();
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Sesión cerrada')),
                  );
                }
              },
            ),

          const SizedBox(height: 32),
          Text(
            'NEXORA · Versión 4.2\n'
            'La personalización de colores y modo no altera animaciones ni identidad interna.\n'
            'El camuflaje externo (nombre/icono del lanzador) aún no está implementado.',
            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4, top: 8),
      child: Text(text, style: Theme.of(context).textTheme.titleSmall?.copyWith(
        color: Theme.of(context).colorScheme.primary,
        fontWeight: FontWeight.w600,
      )),
    );
  }
}
