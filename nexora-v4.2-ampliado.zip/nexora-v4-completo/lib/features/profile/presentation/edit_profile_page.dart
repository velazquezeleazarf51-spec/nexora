import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/constants.dart';

/// Editor de perfil y datos de creador / portafolio básico.
class EditProfilePage extends ConsumerStatefulWidget {
  const EditProfilePage({super.key});

  @override
  ConsumerState<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends ConsumerState<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final _displayName = TextEditingController();
  final _username = TextEditingController();
  final _bio = TextEditingController();
  final _creatorBio = TextEditingController();
  bool _isCreator = false;
  bool _loading = true;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (!Constants.hasSupabaseCredentials) {
      setState(() {
        _loading = false;
        _error = 'Configura Supabase para editar el perfil.';
      });
      return;
    }
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      setState(() {
        _loading = false;
        _error = 'Inicia sesión para editar tu perfil.';
      });
      return;
    }
    try {
      final row = await Supabase.instance.client
          .from('profiles')
          .select()
          .eq('id', user.id)
          .maybeSingle();
      if (row != null && mounted) {
        _displayName.text = (row['display_name'] ?? row['full_name'] ?? '') as String;
        _username.text = (row['username'] ?? '') as String;
        _bio.text = (row['bio'] ?? '') as String;
        _creatorBio.text = (row['creator_bio'] ?? '') as String;
        _isCreator = row['is_creator'] == true;
      }
      if (mounted) setState(() => _loading = false);
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _error = '$e';
        });
      }
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) return;
    setState(() => _saving = true);
    try {
      await Supabase.instance.client.from('profiles').update({
        'display_name': _displayName.text.trim(),
        'username': _username.text.trim().isEmpty ? null : _username.text.trim(),
        'bio': _bio.text.trim().isEmpty ? null : _bio.text.trim(),
        'is_creator': _isCreator,
        'creator_bio': _isCreator && _creatorBio.text.trim().isNotEmpty
            ? _creatorBio.text.trim()
            : null,
      }).eq('id', user.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Perfil actualizado')),
        );
        Navigator.pop(context, true);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  void dispose() {
    _displayName.dispose();
    _username.dispose();
    _bio.dispose();
    _creatorBio.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Editar perfil'),
        actions: [
          TextButton(
            onPressed: _saving || _loading ? null : _save,
            child: _saving
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Guardar'),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
              : Form(
                  key: _formKey,
                  child: ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      TextFormField(
                        controller: _displayName,
                        decoration: const InputDecoration(
                          labelText: 'Nombre visible',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Iconsax.user),
                        ),
                        validator: (v) =>
                            (v == null || v.trim().isEmpty) ? 'Obligatorio' : null,
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _username,
                        decoration: const InputDecoration(
                          labelText: 'Usuario (sin @)',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Iconsax.tag),
                        ),
                      ),
                      const SizedBox(height: 14),
                      TextFormField(
                        controller: _bio,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          labelText: 'Bio',
                          border: OutlineInputBorder(),
                          alignLabelWithHint: true,
                        ),
                      ),
                      const SizedBox(height: 18),
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('Perfil de creador'),
                        subtitle: const Text(
                          'Activa herramientas de portafolio y donaciones (cuando estén disponibles).',
                        ),
                        value: _isCreator,
                        onChanged: (v) => setState(() => _isCreator = v),
                      ),
                      if (_isCreator) ...[
                        const SizedBox(height: 8),
                        TextFormField(
                          controller: _creatorBio,
                          maxLines: 4,
                          decoration: const InputDecoration(
                            labelText: 'Descripción de creador / portafolio',
                            hintText: 'Proyectos, estilo, enlaces de trabajo…',
                            border: OutlineInputBorder(),
                            alignLabelWithHint: true,
                          ),
                        ),
                      ],
                      const SizedBox(height: 24),
                      Text(
                        'Avatar, portada y secciones destacadas del portafolio se completarán en una siguiente iteración de carga de archivos.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
    );
  }
}
