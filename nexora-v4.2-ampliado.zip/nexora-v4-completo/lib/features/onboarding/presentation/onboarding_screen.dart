import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:iconsax/iconsax.dart';

import '../../../core/constants.dart';

/// Onboarding inicial: propósitos de uso + confirmación de edad + política.
/// Estado: interfaz básica preparada.
/// Falta: persistencia completa, aceptación formal de documentos legales
/// y mecanismo real de verificación de mayoría de edad según jurisdicción.
class OnboardingScreen extends ConsumerStatefulWidget {
  const OnboardingScreen({super.key, required this.onCompleted});
  final VoidCallback onCompleted;

  @override
  ConsumerState<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends ConsumerState<OnboardingScreen> {
  final Set<String> _selected = {};
  bool _ageConfirmed = false;
  bool _privacyAccepted = false;
  bool _saving = false;

  static const _purposes = [
    ('personal', 'Uso personal', Iconsax.user),
    ('social', 'Conversar y conocer personas', Iconsax.messages_2),
    ('discover', 'Investigar y descubrir contenido', Iconsax.search_normal),
    ('art', 'Compartir dibujos y arte', Iconsax.brush_1),
    ('animation', 'Publicar animaciones', Iconsax.video_play),
    ('video', 'Compartir videos', Iconsax.video),
    ('projects', 'Mostrar proyectos', Iconsax.folder_2),
    ('communities', 'Crear comunidades', Iconsax.people),
    ('games', 'Compartir o descubrir juegos', Iconsax.game),
  ];

  Future<void> _finish() async {
    if (!_ageConfirmed || !_privacyAccepted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Debes confirmar la edad y aceptar la política de privacidad.')),
      );
      return;
    }
    setState(() => _saving = true);

    if (Constants.hasSupabaseCredentials) {
      try {
        final userId = Supabase.instance.client.auth.currentUser?.id;
        if (userId != null) {
          await Supabase.instance.client.from('profiles').update({
            'interests': _selected.toList(),
            'account_purposes': _selected.toList(),
            'onboarding_completed': true,
            'age_verified_at': DateTime.now().toIso8601String(),
            'privacy_policy_version': '2026-11-01',
            'privacy_accepted_at': DateTime.now().toIso8601String(),
          }).eq('id', userId);
        }
      } catch (_) {
        // Continuar aunque falle la persistencia; el flujo no debe bloquearse.
      }
    }

    if (mounted) {
      setState(() => _saving = false);
      widget.onCompleted();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Bienvenido a NEXORA')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            '¿Para qué quieres usar NEXORA?',
            style: theme.textTheme.titleLarge,
          ),
          const SizedBox(height: 6),
          Text(
            'Puedes elegir varias opciones. Las usaremos para personalizar recomendaciones. '
            'No limitan el acceso a otras funciones.',
            style: theme.textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: _purposes.map((p) {
              final selected = _selected.contains(p.$1);
              return FilterChip(
                avatar: Icon(p.$3, size: 18),
                label: Text(p.$2),
                selected: selected,
                onSelected: (v) {
                  setState(() {
                    if (v) {
                      _selected.add(p.$1);
                    } else {
                      _selected.remove(p.$1);
                    }
                  });
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 28),
          const Divider(),
          const SizedBox(height: 12),
          Text('Requisitos', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            value: _ageConfirmed,
            onChanged: (v) => setState(() => _ageConfirmed = v ?? false),
            title: const Text('Confirmo que tengo 18 años o más'),
            subtitle: const Text(
              'NEXORA está dirigida a personas adultas. '
              'Pedir solo una fecha de nacimiento no equivale necesariamente a verificar la edad. '
              'Se implementará un mecanismo apropiado según los países de operación.',
            ),
          ),
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            value: _privacyAccepted,
            onChanged: (v) => setState(() => _privacyAccepted = v ?? false),
            title: const Text('Acepto la Política de privacidad y los Términos de uso'),
            subtitle: const Text(
              'Los documentos legales definitivos están pendientes de redacción y revisión jurídica.',
            ),
          ),
          const SizedBox(height: 28),
          FilledButton(
            onPressed: _saving ? null : _finish,
            child: _saving
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Continuar'),
          ),
        ],
      ),
    );
  }
}
