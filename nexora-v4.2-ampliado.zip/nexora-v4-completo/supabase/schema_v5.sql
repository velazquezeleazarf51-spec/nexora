-- NEXORA V5: ampliación social, creadores, descargas, juegos y preferencias.
-- Ejecutar DESPUÉS de schema_base.sql y schema_v4.sql.
-- Antes de producción, revisar políticas y configurar proveedores externos.

alter table public.profiles
  add column if not exists interests text[] not null default '{}',
  add column if not exists is_creator boolean not null default false,
  add column if not exists creator_bio text,
  add column if not exists cover_url text,
  add column if not exists theme_color text not null default '#8B7CF6',
  add column if not exists theme_mode text not null default 'dark'
    check (theme_mode in ('dark','light','system')),
  add column if not exists background_url text,
  add column if not exists onboarding_completed boolean not null default false,
  add column if not exists age_verified_at timestamptz,
  add column if not exists privacy_policy_version text,
  add column if not exists cookie_preferences jsonb not null default '{"necessary":true,"analytics":false,"marketing":false}'::jsonb;

-- El usuario no puede elevarse a administrador modificando su propio perfil.
create or replace function public.prevent_self_admin_escalation()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if new.is_admin is distinct from old.is_admin and coalesce(auth.role(), '') <> 'service_role' then
    raise exception 'El rol de administrador solo puede cambiarse desde un proceso confiable';
  end if;
  return new;
end;
$$;
drop trigger if exists protect_profile_admin_role on public.profiles;
create trigger protect_profile_admin_role before update on public.profiles
for each row execute function public.prevent_self_admin_escalation();

alter table public.posts
  add column if not exists likes_count integer not null default 0,
  add column if not exists is_approved boolean not null default true,
  add column if not exists video_duration_seconds integer,
  add column if not exists category text,
  add column if not exists download_count bigint not null default 0;
create index if not exists posts_approved_created_idx on public.posts(is_approved, created_at desc);
do $$ begin
  alter table public.posts add constraint posts_video_duration_limit
  check (video_duration_seconds is null or video_duration_seconds between 0 and 1440);
exception when duplicate_object then null; end $$;



-- Mantener contador de likes que consume el feed.
create or replace function public.sync_post_likes_count()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    update public.posts set likes_count = likes_count + 1 where id = new.post_id;
    return new;
  elsif tg_op = 'DELETE' then
    update public.posts set likes_count = greatest(0, likes_count - 1) where id = old.post_id;
    return old;
  end if;
  return null;
end;
$$;
drop trigger if exists likes_count_insert on public.likes;
create trigger likes_count_insert after insert on public.likes for each row execute function public.sync_post_likes_count();
drop trigger if exists likes_count_delete on public.likes;
create trigger likes_count_delete after delete on public.likes for each row execute function public.sync_post_likes_count();

-- Seguimiento de personas.
create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  followed_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, followed_id),
  check (follower_id <> followed_id)
);
alter table public.follows enable row level security;
drop policy if exists follows_read on public.follows;
create policy follows_read on public.follows for select to authenticated using (true);
drop policy if exists follows_insert_self on public.follows;
create policy follows_insert_self on public.follows for insert to authenticated with check (auth.uid() = follower_id);
drop policy if exists follows_delete_self on public.follows;
create policy follows_delete_self on public.follows for delete to authenticated using (auth.uid() = follower_id);


create or replace function public.add_community_owner_membership()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.community_members(community_id, user_id, role, status)
  values (new.id, new.owner_id, 'owner', 'active')
  on conflict (community_id, user_id) do nothing;
  return new;
end;
$$;
drop trigger if exists community_owner_membership on public.communities;
create trigger community_owner_membership after insert on public.communities
for each row execute function public.add_community_owner_membership();

-- Comentarios.
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 2000),
  created_at timestamptz not null default now()
);
alter table public.comments enable row level security;
drop policy if exists comments_read on public.comments;
create policy comments_read on public.comments for select using (true);
drop policy if exists comments_insert_self on public.comments;
create policy comments_insert_self on public.comments for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists comments_delete_owner_admin on public.comments;
create policy comments_delete_owner_admin on public.comments for delete to authenticated using (auth.uid() = user_id or public.is_admin());

-- Comunidades y membresías.
create table if not exists public.communities (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  description text not null default '',
  is_private boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.community_members (
  community_id uuid not null references public.communities(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','moderator','member')),
  status text not null default 'active' check (status in ('pending','active','banned')),
  created_at timestamptz not null default now(),
  primary key (community_id, user_id)
);
create table if not exists public.community_posts (
  id uuid primary key default gen_random_uuid(),
  community_id uuid not null references public.communities(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '',
  media_url text,
  media_type text,
  allow_download boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.communities enable row level security;
alter table public.community_members enable row level security;
alter table public.community_posts enable row level security;
drop policy if exists communities_read on public.communities;
create policy communities_read on public.communities for select to authenticated
using (not is_private or owner_id = auth.uid() or exists (
  select 1 from public.community_members m where m.community_id = id and m.user_id = auth.uid() and m.status = 'active'
) or public.is_admin());
drop policy if exists communities_create on public.communities;
create policy communities_create on public.communities for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists community_members_read on public.community_members;
create policy community_members_read on public.community_members for select to authenticated
using (user_id = auth.uid() or public.is_admin());
drop policy if exists community_members_join on public.community_members;
create policy community_members_join on public.community_members for insert to authenticated with check (user_id = auth.uid() and role = 'member' and status in ('active','pending'));
drop policy if exists community_posts_read on public.community_posts;
create policy community_posts_read on public.community_posts for select to authenticated using (
  exists(select 1 from public.communities c where c.id = community_id and (not c.is_private or c.owner_id = auth.uid()
    or exists(select 1 from public.community_members m where m.community_id = c.id and m.user_id = auth.uid() and m.status = 'active')))
);
drop policy if exists community_posts_insert on public.community_posts;
create policy community_posts_insert on public.community_posts for insert to authenticated with check (
  auth.uid() = user_id and exists(select 1 from public.community_members m where m.community_id = community_id and m.user_id = auth.uid() and m.status = 'active')
);

-- Notificaciones.
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  type text not null,
  entity_id uuid,
  body text not null default '',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
alter table public.notifications enable row level security;
drop policy if exists notifications_read_self on public.notifications;
create policy notifications_read_self on public.notifications for select to authenticated using (auth.uid() = user_id);
drop policy if exists notifications_update_self on public.notifications;
create policy notifications_update_self on public.notifications for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Juegos: paquetes HTML5/WebGL en cuarentena hasta aprobación.
create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 100),
  description text not null default '',
  category text not null default 'Otro',
  package_path text not null,
  package_type text not null check (package_type in ('html5_zip','webgl')),
  thumbnail_url text,
  offline_supported boolean not null default false,
  status text not null default 'pending' check (status in ('pending','approved','rejected','disabled')),
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  review_note text,
  created_at timestamptz not null default now()
);
alter table public.games enable row level security;
drop policy if exists games_public_approved on public.games;
create policy games_public_approved on public.games for select to authenticated using (status = 'approved' or creator_id = auth.uid() or public.is_admin());
drop policy if exists games_submit on public.games;
create policy games_submit on public.games for insert to authenticated with check (creator_id = auth.uid() and status = 'pending');
drop policy if exists games_admin_review on public.games;
create policy games_admin_review on public.games for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Donaciones: solo registra estados verificados por backend/webhook.
create table if not exists public.donation_events (
  id uuid primary key default gen_random_uuid(),
  donor_id uuid references public.profiles(id) on delete set null,
  creator_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  currency text not null default 'MXN',
  provider text not null,
  provider_reference text unique,
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.donation_events enable row level security;
drop policy if exists donations_participant_read on public.donation_events;
create policy donations_participant_read on public.donation_events for select to authenticated
using (auth.uid() = donor_id or auth.uid() = creator_id or public.is_admin());
-- No cliente puede insertar pagos confirmados ni cambiar su estado. Crear operaciones desde backend seguro.
drop policy if exists donations_no_client_insert on public.donation_events;
create policy donations_no_client_insert on public.donation_events for insert to authenticated with check (false);
drop policy if exists donations_no_client_update on public.donation_events;
create policy donations_no_client_update on public.donation_events for update to authenticated using (false);

-- Registro de consentimientos.
create table if not exists public.user_consents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  consent_type text not null,
  version text not null,
  accepted boolean not null,
  created_at timestamptz not null default now()
);
alter table public.user_consents enable row level security;
drop policy if exists consents_read_self on public.user_consents;
create policy consents_read_self on public.user_consents for select to authenticated using (auth.uid() = user_id);
drop policy if exists consents_insert_self on public.user_consents;
create policy consents_insert_self on public.user_consents for insert to authenticated with check (auth.uid() = user_id);

-- Publicación realtime para las notificaciones.
do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null; when others then null; end $$;

-- IMPORTANTE:
-- Crear buckets separados para juegos y fondos. No hacerlos públicos.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('game-submissions','game-submissions',false,104857600,array['application/zip','application/x-zip-compressed'])
on conflict (id) do nothing;
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('user-backgrounds','user-backgrounds',false,10485760,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists game_upload_own_folder on storage.objects;
create policy game_upload_own_folder on storage.objects for insert to authenticated
with check (bucket_id = 'game-submissions' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists game_read_admin_or_owner on storage.objects;
create policy game_read_admin_or_owner on storage.objects for select to authenticated
using (bucket_id = 'game-submissions' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
drop policy if exists background_upload_own_folder on storage.objects;
create policy background_upload_own_folder on storage.objects for insert to authenticated
with check (bucket_id = 'user-backgrounds' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists background_read_own_folder on storage.objects;
create policy background_read_own_folder on storage.objects for select to authenticated
using (bucket_id = 'user-backgrounds' and (storage.foldername(name))[1] = auth.uid()::text);
