-- NEXORA V6: seguridad de descargas, columnas de contenido y preferencias adicionales.
-- Ejecutar DESPUÉS de schema_base.sql, schema_v4.sql y schema_v5.sql.
-- Revisar siempre en entorno de pruebas antes de producción.

-- ============================================================
-- 1. Columnas adicionales en posts (compatibilidad con requisitos)
-- ============================================================
alter table public.posts
  add column if not exists is_short_video boolean not null default false,
  add column if not exists content_category text,
  add column if not exists download_enabled boolean,
  add column if not exists downloadable_file_url text,
  add column if not exists moderation_status text not null default 'approved'
    check (moderation_status in ('pending', 'approved', 'rejected', 'removed')),
  add column if not exists private_media_path text;

-- Sincronizar download_enabled con allow_download existente si aplica
update public.posts
set download_enabled = coalesce(download_enabled, allow_download, false)
where download_enabled is null;

-- Índice para Reels
create index if not exists posts_short_video_idx
  on public.posts (is_short_video, created_at desc)
  where is_short_video = true and is_approved = true;

-- ============================================================
-- 2. Preferencias de cuenta adicionales (registro / onboarding)
-- ============================================================
alter table public.profiles
  add column if not exists account_purposes text[] not null default '{}',
  add column if not exists privacy_accepted_at timestamptz;

-- ============================================================
-- 3. Bucket privado para contenido con descarga restringida
-- ============================================================
-- El bucket público "media" sigue existiendo para contenido abierto.
-- El contenido con allow_download = false o sensible debe subirse a media-private.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'media-private',
  'media-private',
  false,
  104857600, -- 100 MB
  array[
    'image/png', 'image/jpeg', 'image/webp', 'image/gif',
    'video/mp4', 'video/webm',
    'application/pdf',
    'application/zip'
  ]
)
on conflict (id) do nothing;

-- Solo el dueño puede subir a su carpeta
drop policy if exists "media_private_upload_own" on storage.objects;
create policy "media_private_upload_own" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'media-private'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

-- Lectura: dueño o admin (las URLs firmadas se generan en servidor/cliente autenticado)
drop policy if exists "media_private_read_own_or_admin" on storage.objects;
create policy "media_private_read_own_or_admin" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'media-private'
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or public.is_admin()
    )
  );

-- Borrado: dueño o admin
drop policy if exists "media_private_delete_own_or_admin" on storage.objects;
create policy "media_private_delete_own_or_admin" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'media-private'
    and (
      (storage.foldername(name))[1] = auth.uid()::text
      or public.is_admin()
    )
  );

-- ============================================================
-- 4. Tabla de reportes (si no existía de forma completa)
-- ============================================================
create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  target_type text not null check (target_type in ('post', 'user', 'comment', 'community', 'game', 'message')),
  target_id uuid not null,
  reason text not null,
  status text not null default 'open' check (status in ('open', 'reviewing', 'resolved', 'dismissed')),
  admin_notes text,
  created_at timestamptz not null default now(),
  resolved_at timestamptz,
  resolved_by uuid references public.profiles(id)
);

alter table public.reports enable row level security;

drop policy if exists "reports_insert_self" on public.reports;
create policy "reports_insert_self" on public.reports
  for insert to authenticated
  with check (auth.uid() = reporter_id);

drop policy if exists "reports_read_admin_or_self" on public.reports;
create policy "reports_read_admin_or_self" on public.reports
  for select to authenticated
  using (auth.uid() = reporter_id or public.is_admin());

drop policy if exists "reports_update_admin" on public.reports;
create policy "reports_update_admin" on public.reports
  for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- ============================================================
-- 5. Realtime (notificaciones y mensajes si aplica)
-- ============================================================
-- Ejecutar en el panel de Supabase si aún no está:
-- alter publication supabase_realtime add table public.notifications;
-- alter publication supabase_realtime add table public.messages;

-- ============================================================
-- NOTAS DE SEGURIDAD
-- ============================================================
-- 1. No confiar solo en ocultar el botón de descarga en la UI.
-- 2. Para archivos que el autor no quiere que se descarguen libremente:
--    subir a media-private y servir con createSignedUrl de corta duración.
-- 3. Validar MIME real, tamaño y duración de video (máx. 1440 s) en cliente y, si es posible, en Edge Function.
-- 4. Nunca incluir service_role en la app Flutter.
-- 5. Probar RLS con al menos: usuario normal, creador, admin y usuario no autenticado.
