-- ============================================================
-- Nexora · Schema base (v1) · Ejecutar PRIMERO
-- ============================================================
-- Extensiones
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ============================================================
-- PERFILES
-- ============================================================
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text,
  avatar_url text,
  bio text default '',
  is_admin boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce(
    (select is_admin from public.profiles where id = auth.uid()),
    false
  );
$$;

create policy "Perfiles públicos lectura" on public.profiles
  for select using (true);

create policy "Usuario actualiza su perfil" on public.profiles
  for update to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

create policy "Usuario inserta su perfil" on public.profiles
  for insert to authenticated
  with check (auth.uid() = id);

-- Trigger: crear perfil al registrarse
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1))
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- POSTS (estilo X)
-- ============================================================
create table if not exists public.posts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '' check (char_length(content) <= 2000),
  media_url text,
  media_type text check (media_type is null or media_type in ('image', 'video')),
  allow_download boolean not null default false,
  hashtags text[] default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists posts_user_idx on public.posts(user_id, created_at desc);
create index if not exists posts_created_idx on public.posts(created_at desc);

alter table public.posts enable row level security;

create policy "Posts visibles" on public.posts for select using (true);
create policy "Usuario crea post" on public.posts for insert to authenticated
  with check (auth.uid() = user_id);
create policy "Usuario borra su post" on public.posts for delete to authenticated
  using (auth.uid() = user_id or public.is_admin());
create policy "Usuario edita su post" on public.posts for update to authenticated
  using (auth.uid() = user_id);

-- ============================================================
-- LIKES / SAVES / REPORTS
-- ============================================================
create table if not exists public.likes (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

create table if not exists public.saves (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

create table if not exists public.reports (
  id uuid primary key default uuid_generate_v4(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete set null,
  reason text,
  status text not null default 'pending' check (status in ('pending', 'reviewed', 'dismissed')),
  created_at timestamptz not null default now()
);

alter table public.likes enable row level security;
alter table public.saves enable row level security;
alter table public.reports enable row level security;

create policy "Likes visibles" on public.likes for select using (true);
create policy "Usuario like" on public.likes for insert to authenticated with check (auth.uid() = user_id);
create policy "Usuario quita like" on public.likes for delete to authenticated using (auth.uid() = user_id);

create policy "Saves propios" on public.saves for select to authenticated using (auth.uid() = user_id);
create policy "Usuario guarda" on public.saves for insert to authenticated with check (auth.uid() = user_id);
create policy "Usuario quita save" on public.saves for delete to authenticated using (auth.uid() = user_id);

create policy "Reports admin" on public.reports for select to authenticated using (public.is_admin());
create policy "Usuario reporta" on public.reports for insert to authenticated with check (auth.uid() = reporter_id);

-- ============================================================
-- APP SECTIONS (módulos dinámicos)
-- ============================================================
create table if not exists public.app_sections (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  description text,
  route_key text not null,
  icon text default 'apps',
  is_visible boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

alter table public.app_sections enable row level security;
create policy "Sections visibles" on public.app_sections for select using (is_visible = true or public.is_admin());
create policy "Admin gestiona sections" on public.app_sections for all to authenticated using (public.is_admin());

-- ============================================================
-- MENSAJES (base chat)
-- ============================================================
create table if not exists public.messages (
  id uuid primary key default uuid_generate_v4(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid references public.profiles(id) on delete cascade, -- null = grupo futuro
  room_id uuid, -- para grupos futuros
  content text,
  created_at timestamptz not null default now()
);

create index if not exists messages_room_idx on public.messages(room_id, created_at);
create index if not exists messages_sender_idx on public.messages(sender_id, created_at desc);

alter table public.messages enable row level security;

create policy "Mensajes propios" on public.messages for select to authenticated
  using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "Usuario envía mensaje" on public.messages for insert to authenticated
  with check (auth.uid() = sender_id);

-- Realtime
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.posts;
alter publication supabase_realtime add table public.likes;

-- ============================================================
-- STORAGE: bucket media (feed + chat)
-- ============================================================
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'media',
  'media',
  true,
  104857600, -- 100 MB
  array['image/png','image/jpeg','image/webp','image/gif','video/mp4','video/webm','audio/mpeg','audio/mp4','application/pdf']
)
on conflict (id) do update set
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

create policy "media lectura pública" on storage.objects
  for select using (bucket_id = 'media');

create policy "media subir propio" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "media borrar propio" on storage.objects
  for delete to authenticated
  using (bucket_id = 'media' and (storage.foldername(name))[1] = auth.uid()::text);
