-- NEXORA V7: bloqueos, preferencias de notificación y ajustes de moderación.
-- Ejecutar DESPUÉS de schema_v6.sql.

-- ============================================================
-- Bloqueos entre usuarios
-- ============================================================
create table if not exists public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);

alter table public.blocks enable row level security;

drop policy if exists blocks_read_self on public.blocks;
create policy blocks_read_self on public.blocks
  for select to authenticated
  using (auth.uid() = blocker_id or public.is_admin());

drop policy if exists blocks_insert_self on public.blocks;
create policy blocks_insert_self on public.blocks
  for insert to authenticated
  with check (auth.uid() = blocker_id);

drop policy if exists blocks_delete_self on public.blocks;
create policy blocks_delete_self on public.blocks
  for delete to authenticated
  using (auth.uid() = blocker_id or public.is_admin());

-- ============================================================
-- Preferencias de notificación (si aún no estaban completas)
-- ============================================================
-- profiles.cookie_preferences ya existe en V5 como jsonb.
-- Asegurar valor por defecto coherente.
alter table public.profiles
  alter column cookie_preferences set default
    '{"necessary":true,"analytics":false,"marketing":false}'::jsonb;

-- ============================================================
-- Índice útil para chat (mensajes por pareja)
-- ============================================================
create index if not exists messages_pair_idx
  on public.messages (sender_id, receiver_id, created_at desc);

create index if not exists messages_pair_rev_idx
  on public.messages (receiver_id, sender_id, created_at desc);

-- ============================================================
-- Notas
-- ============================================================
-- Las políticas de feed deberían filtrar autores bloqueados en el cliente
-- y, idealmente, con una vista o función en el servidor en una fase posterior.
-- No incluir service_role en la aplicación cliente.
