# NEXORA — Estado actualizado (implementación amplia)

**Fecha**: 7 de noviembre de 2026  
**Base**: NEXORA 4.2 + requisitos del documento maestro

## Implementado en código (esta sesión)

### Base y arquitectura
- Estructura modular por features
- Modelos Profile, Post
- Repositorios: Reels, Discover, Communities, Notifications, Posts, Chat, Moderation
- StorageService (URLs públicas + firmadas + permiso de descarga)
- Migraciones SQL: base, v4, v5, v6 (media-private, reportes), v7 (blocks)

### Auth y onboarding
- Login / registro
- RootGate: onboarding si hay sesión y onboarding_completed = false
- Escucha de cambios de sesión
- Preferencias de uso, edad, privacidad

### Social
- Feed + descarga respetando permiso
- Reels verticales
- Explorar: búsqueda, seguir, mensaje, denunciar, bloquear
- Comentarios (hoja modal)
- Comunidades: listado, crear, unirse/solicitar, detalle
- Notificaciones: bandeja + marcar leídas
- Chat: lista, sala 1:1, Realtime, multimedia

### Creadores y juegos
- Editar perfil + modo creador / bio
- Biblioteca de juegos aprobados
- Envío ZIP HTML5 → pending
- Admin: aprobar / rechazar juegos

### Personalización y privacidad
- Color libre + modo claro/oscuro
- Preferencias de cookies

### Navegación
- Inicio · Reels · Explorar · Juegos · Avisos · Chat (+ Admin)

## NO terminado (honesto)

| Área | Qué falta |
|------|-----------|
| Supabase remoto | Ejecutar migraciones y probar RLS de verdad |
| Storage | Migrar subidas sensibles a media-private |
| Historias | Expiración estricta, privacidad, moderación |
| Reels | Precarga, reportes UI, optimización |
| Chat | Bloqueo en hilo, anti-spam, grupos, push |
| Comunidades | Roles, moderación de solicitudes |
| Portafolio | Avatar/portada, secciones, galería |
| Donaciones | Proveedor + webhooks (tabla sola no cobra) |
| Juegos offline | Sandbox, descarga local, espacio |
| Camuflaje launcher | Android nativo + pruebas |
| Legal | Textos definitivos revisados |
| Edad | Verificación real según país |
| APK | Compilar y probar en dispositivos |
| Diseño | Esperar video de referencia del usuario |

## Orden de migraciones
1. schema_base.sql
2. schema_v4.sql
3. schema_v5.sql
4. schema_v6.sql
5. schema_v7.sql

## Reglas
- No declarar terminado lo parcial
- Videos ≤ 24 min; Reels aparte
- Juegos solo tras revisión admin
- Sin service_role en el cliente
