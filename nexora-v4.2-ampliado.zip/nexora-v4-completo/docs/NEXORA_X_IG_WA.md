# Nexora = X + Instagram + WhatsApp

## Visión de producto

| Red | Qué toma Nexora |
|-----|-----------------|
| **X (Twitter)** | Feed de publicaciones, #hashtags, likes, reportes |
| **Instagram** | Estados/stories 24h, videos e imágenes en el feed |
| **WhatsApp** | Chat 1:1 (y grupos después) con texto, imagen y video |

## Estados (stories)

- Tabla `stories`: imagen o video corto, caption, expira a las 24h
- Se suben al bucket `stories`
- Vistas en `story_views`
- UI: fila de círculos arriba del feed (como IG/WhatsApp)

## Chat con media

- `messages` admite `media_url` + `media_type` (`image` | `video` | `audio` | `file`)
- Texto opcional si hay archivo
- Mismo bucket `media` que el feed
- UI: botón adjuntar en el chat

## Feed (X)

- Posts con texto, #tags, video hasta 24 min, allow_download

## SQL

Ejecutar en orden: schema.sql → v2 → v3 → **v4**.
