# Setup Supabase para NEXORA

## 1. Crear proyecto en Supabase

1. Entra a https://supabase.com → **New project**.
2. Anota la **Project URL** y la **anon public key** (Settings → API).
3. **Nunca** uses ni distribuyas la `service_role` key en la app.

## 2. Orden de migraciones SQL

Ejecutar en el SQL Editor de un proyecto de **pruebas**, en este orden:

1. `supabase/schema_base.sql`
2. `supabase/schema_v4.sql`
3. `supabase/schema_v5.sql`
4. `supabase/schema_v6.sql` ← seguridad de descargas, columnas de Reels/moderación, reportes

Antes de producción:

- Hacer respaldo.
- Revisar el SQL completo.
- Confirmar políticas RLS con cuentas de distintos roles.
- Verificar que un usuario no pueda consultar ni modificar datos ajenos.

## 3. Credenciales en la app Flutter

Solo:

- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Opciones:

- Archivo `.env` (desarrollo local)
- `--dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...` (builds de release)

## 4. Buckets de Storage

| Bucket | Público | Uso |
|--------|---------|-----|
| `media` | Sí | Contenido del feed abierto (legacy) |
| `media-private` | No | Contenido con descarga restringida / sensible |
| `stories` | Lectura pública | Historias temporales |
| `game-submissions` | No | Paquetes ZIP de juegos enviados |
| `backgrounds` | Según política | Fondos de personalización |

### Seguridad de descargas (crítico)

- Ocultar el botón «Descargar» en la UI **no protege** el archivo si la URL es pública.
- Para publicaciones con descarga restringida o contenido sensible:
  1. Subir a `media-private`.
  2. Guardar la ruta en `private_media_path` (o equivalente).
  3. Servir con `createSignedUrl` de corta duración (p. ej. 15 minutos).
- Validar tipo MIME real, tamaño y duración de video (máximo **1440 segundos / 24 minutos**).

## 5. Realtime

Si aún no están en la publicación:

```sql
alter publication supabase_realtime add table public.notifications;
alter publication supabase_realtime add table public.messages;
```

## 6. Pruebas mínimas de RLS

1. Usuario A no puede editar el perfil de Usuario B.
2. Usuario A no puede aprobar juegos (solo admin).
3. Usuario A no puede leer archivos de `game-submissions` de otro usuario.
4. Usuario A no puede leer objetos de `media-private` de otro usuario.
5. Posts no aprobados no aparecen en el feed público.

## 7. Donaciones y pagos

La tabla `donation_events` existe. **No procesa pagos por sí sola**.  
Se necesita proveedor externo, funciones de servidor (Edge Functions) y webhooks verificados.

## 8. Checklist rápido

- [ ] Migraciones ejecutadas en orden en proyecto de pruebas
- [ ] RLS verificado con roles distintos
- [ ] Buckets creados y políticas de Storage activas
- [ ] `.env` o dart-define configurados (sin service_role)
- [ ] `flutter pub get` y `flutter analyze` sin errores bloqueantes
- [ ] Flujos básicos: login, publicar, Reels, buscar, enviar juego, admin
