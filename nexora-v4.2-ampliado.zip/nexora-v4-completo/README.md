# NEXORA

Plataforma social en Flutter con backend Supabase.

## Contenido
- Feed y publicaciones.
- Historias de 24 horas.
- Chat multimedia.
- Base para comunidades, seguimiento, comentarios y notificaciones.
- Preferencias de color y modo claro/oscuro.
- Envío de paquetes de juegos HTML5 para revisión administrativa.
- Migraciones SQL de base, V4 y V5.

## Configuración
1. Instala Flutter compatible con Dart 3.5 o superior.
2. Ejecuta `flutter pub get`.
3. Configura `SUPABASE_URL` y `SUPABASE_ANON_KEY` mediante `.env` local o `--dart-define`.
4. Ejecuta `schema_base.sql`, `schema_v4.sql` y `schema_v5.sql` en ese orden en un proyecto Supabase de pruebas.
5. Revisa `docs/SETUP_SUPABASE.md`.

No incluyas nunca `service_role` en la app.

## Personalización
El usuario puede cambiar el color principal (incluyendo HEX) y el modo claro/oscuro. Las animaciones, la estructura y el estilo original permanecen fijos. Los ajustes actuales se guardan localmente en el dispositivo.

## Estado y limitaciones
Esta es una actualización de la base recibida, no una aplicación final lista para publicar. Fondos propios, camuflaje externo Android, donaciones reales, onboarding, verificación de edad, Reels completos, notificaciones, ejecución aislada y modo offline de juegos requieren desarrollo adicional. El ZIP recibido tampoco incluye un proyecto Android nativo completo. Consulta `NEXORA_ESPECIFICACION_MAESTRA.txt` para el alcance y los pendientes.

## Build
Cuando el proyecto Android nativo esté completo:
```bash
flutter pub get
flutter analyze
flutter build apk --release --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
```
