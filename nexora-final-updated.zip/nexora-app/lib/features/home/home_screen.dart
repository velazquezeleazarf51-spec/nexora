import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../core/constants.dart';
import '../../theme/theme_provider.dart';
import '../auth/presentation/login_screen.dart';

class DemoPost {
  DemoPost({
    required this.author,
    required this.handle,
    required this.time,
    required this.text,
    required this.tag,
    required this.color,
    required this.likes,
    this.liked = false,
    this.saved = false,
  });

  final String author;
  final String handle;
  final String time;
  final String text;
  final String tag;
  final Color color;
  int likes;
  bool liked;
  bool saved;
}

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({
    super.key,
    required this.supabaseReady,
    this.isDemo = false,
    this.displayName = 'Explorador',
  });

  final bool supabaseReady;
  final bool isDemo;
  final String displayName;

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _selectedIndex = 0;
  final List<DemoPost> _posts = [
    DemoPost(
      author: 'Sofía Martínez',
      handle: '@sofia.crea',
      time: 'hace 12 min',
      text: 'Hoy terminé una ilustración en la que llevaba días trabajando. A veces crear sin prisa también es avanzar.',
      tag: 'Ilustración',
      color: const Color(0xFF8B7CF6),
      likes: 28,
    ),
    DemoPost(
      author: 'Leo Vargas',
      handle: '@leo_juega',
      time: 'hace 38 min',
      text: 'Estoy probando un minijuego de plataformas que hice. ¿Quién se anima a darme feedback?',
      tag: 'Proyecto',
      color: const Color(0xFF29B6A5),
      likes: 16,
    ),
    DemoPost(
      author: 'Mara Ríos',
      handle: '@mararios',
      time: 'hace 1 h',
      text: 'Recordatorio amistoso: tu espacio creativo no tiene que parecerse al de nadie más.',
      tag: 'Comunidad',
      color: const Color(0xFFFF9C70),
      likes: 43,
    ),
  ];

  static const _destinations = <_Destination>[
    _Destination('Inicio', Icons.home_rounded, Icons.home_outlined),
    _Destination('Juegos', Icons.sports_esports_rounded, Icons.sports_esports_outlined),
    _Destination('Chat', Icons.chat_bubble_rounded, Icons.chat_bubble_outline_rounded),
    _Destination('Analítica', Icons.insights_rounded, Icons.insights_outlined),
    _Destination('Admin', Icons.admin_panel_settings_rounded, Icons.admin_panel_settings_outlined),
  ];

  void _notify(String message) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
  }

  Future<void> _signOut() async {
    if (widget.supabaseReady && !widget.isDemo) {
      try {
        await Supabase.instance.client.auth.signOut();
      } catch (_) {
        _notify('No se pudo cerrar la sesión. Inténtalo otra vez.');
        return;
      }
    }
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(
        builder: (_) => LoginScreen(supabaseReady: widget.supabaseReady),
      ),
      (_) => false,
    );
  }

  Future<void> _composePost() async {
    final controller = TextEditingController();
    final submitted = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          8,
          20,
          MediaQuery.of(sheetContext).viewInsets.bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('Nueva publicación', style: Theme.of(sheetContext).textTheme.titleLarge),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              autofocus: true,
              minLines: 3,
              maxLines: 6,
              maxLength: 1000,
              decoration: const InputDecoration(
                hintText: '¿Qué quieres compartir?',
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              children: const [
                _MediaChip(icon: Icons.image_outlined, label: 'Imagen'),
                _MediaChip(icon: Icons.movie_outlined, label: 'Video'),
                _MediaChip(icon: Icons.picture_as_pdf_outlined, label: 'PDF'),
                _MediaChip(icon: Icons.sports_esports_outlined, label: 'Juego'),
              ],
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: () => Navigator.pop(sheetContext, controller.text.trim()),
              icon: const Icon(Icons.send_rounded),
              label: const Text('Publicar'),
            ),
          ],
        ),
      ),
    );
    controller.dispose();
    if (submitted == null || submitted.trim().isEmpty) return;
    setState(() {
      _posts.insert(
        0,
        DemoPost(
          author: widget.displayName,
          handle: '@${_safeHandle(widget.displayName)}',
          time: 'ahora',
          text: submitted.trim(),
          tag: 'Nuevo',
          color: Theme.of(context).colorScheme.primary,
          likes: 0,
        ),
      );
      _selectedIndex = 0;
    });
    _notify(widget.supabaseReady && !widget.isDemo
        ? 'Publicación añadida a la vista local. La conexión al feed está en desarrollo.'
        : 'Publicación creada en este prototipo; no se ha enviado a un servidor.');
  }

  String _safeHandle(String name) => name
      .toLowerCase()
      .replaceAll(RegExp(r'[^a-z0-9]+'), '.')
      .replaceAll(RegExp(r'^\.+|\.+$'), '');

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final page = switch (_selectedIndex) {
      0 => _buildFeed(),
      1 => const _GamesPage(),
      2 => const _ChatPage(),
      3 => const _InsightsPage(),
      _ => const _AdminPage(),
    };

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.hub_rounded, color: theme.colorScheme.primary, size: 24),
            const SizedBox(width: 9),
            const Text('nexora', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -0.4)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Cambiar tema',
            onPressed: ref.read(themeProvider.notifier).toggleDarkMode,
            icon: Icon(theme.brightness == Brightness.dark
                ? Icons.light_mode_outlined
                : Icons.dark_mode_outlined),
          ),
          IconButton(
            tooltip: 'Cerrar sesión',
            onPressed: _signOut,
            icon: const Icon(Icons.logout_rounded),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Column(
        children: [
          _DemoBanner(onTap: () => _notify(
            'El feed, los juegos y las métricas todavía muestran datos de ejemplo. La integración del backend sigue pendiente.',
          )),
          Expanded(child: page),
        ],
      ),
      floatingActionButton: _selectedIndex == 0
          ? FloatingActionButton.extended(
              onPressed: _composePost,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Crear'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) => setState(() => _selectedIndex = index),
        destinations: [
          for (var i = 0; i < _destinations.length; i++)
            NavigationDestination(
              icon: Icon(_destinations[i].icon),
              selectedIcon: Icon(_destinations[i].selectedIcon),
              label: _destinations[i].label,
            ),
        ],
      ),
    );
  }

  Widget _buildFeed() {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 96),
      children: [
        Text('Tu comunidad', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        Text('Ideas, proyectos y personas que inspiran.',
            style: theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.onSurface.withOpacity(.62))),
        const SizedBox(height: 18),
        _QuickShare(onTap: _composePost),
        const SizedBox(height: 20),
        Row(
          children: [
            Text('Lo más reciente', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
            const Spacer(),
            Icon(Icons.tune_rounded, size: 18, color: theme.colorScheme.primary),
            const SizedBox(width: 4),
            Text('Para ti', style: theme.textTheme.labelLarge?.copyWith(color: theme.colorScheme.primary)),
          ],
        ),
        const SizedBox(height: 12),
        for (var i = 0; i < _posts.length; i++) ...[
          _PostCard(
            post: _posts[i],
            onLike: () => setState(() {
              final post = _posts[i];
              post.liked = !post.liked;
              post.likes += post.liked ? 1 : -1;
            }),
            onSave: () => setState(() => _posts[i].saved = !_posts[i].saved),
            onMore: () => _showPostOptions(_posts[i]),
          ),
          const SizedBox(height: 12),
        ],
      ],
    );
  }

  void _showPostOptions(DemoPost post) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.flag_outlined),
              title: const Text('Reportar publicación'),
              onTap: () {
                Navigator.pop(sheetContext);
                _showReportDialog(post);
              },
            ),
            ListTile(
              leading: const Icon(Icons.person_off_outlined),
              title: const Text('Dejar de ver publicaciones de esta persona'),
              onTap: () {
                Navigator.pop(sheetContext);
                _notify('Preferencia guardada en esta sesión de demostración.');
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _showReportDialog(DemoPost post) async {
    final reason = await showDialog<String>(
      context: context,
      builder: (dialogContext) => SimpleDialog(
        title: const Text('¿Por qué quieres reportar esto?'),
        children: [
          for (final reason in ['Contenido inapropiado', 'Acoso o spam', 'Información falsa', 'Otro'])
            SimpleDialogOption(
              onPressed: () => Navigator.pop(dialogContext, reason),
              child: Text(reason),
            ),
        ],
      ),
    );
    if (reason != null) _notify('Reporte de «${post.author}» registrado en la vista demo: $reason.');
  }
}

class _Destination {
  const _Destination(this.label, this.icon, this.selectedIcon);
  final String label;
  final IconData icon;
  final IconData selectedIcon;
}

class _DemoBanner extends StatelessWidget {
  const _DemoBanner({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Material(
      color: color.withOpacity(.10),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
          child: Row(
            children: [
              Icon(Icons.science_outlined, size: 17, color: color),
              const SizedBox(width: 9),
              const Expanded(child: Text('Prototipo · el contenido aún no está conectado al servidor', style: TextStyle(fontSize: 12))),
              Icon(Icons.info_outline_rounded, size: 17, color: color),
            ],
          ),
        ),
      ),
    );
  }
}

class _QuickShare extends StatelessWidget {
  const _QuickShare({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: theme.colorScheme.primary.withOpacity(.14),
                child: Icon(Icons.person_rounded, color: theme.colorScheme.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text('Comparte una idea…', style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withOpacity(.58),
                )),
              ),
              const Icon(Icons.add_circle_outline_rounded),
            ],
          ),
        ),
      ),
    );
  }
}

class _PostCard extends StatelessWidget {
  const _PostCard({required this.post, required this.onLike, required this.onSave, required this.onMore});
  final DemoPost post;
  final VoidCallback onLike;
  final VoidCallback onSave;
  final VoidCallback onMore;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(15, 14, 15, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: post.color.withOpacity(.16),
                  child: Text(post.author.characters.first, style: TextStyle(color: post.color, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(post.author, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                    Text('${post.handle} · ${post.time}', style: theme.textTheme.labelSmall?.copyWith(
                      color: theme.colorScheme.onSurface.withOpacity(.55),
                    )),
                  ]),
                ),
                IconButton(tooltip: 'Más opciones', onPressed: onMore, icon: const Icon(Icons.more_horiz_rounded)),
              ],
            ),
            const SizedBox(height: 11),
            Text(post.text, style: theme.textTheme.bodyMedium?.copyWith(height: 1.45)),
            const SizedBox(height: 12),
            DecoratedBox(
              decoration: BoxDecoration(
                color: post.color.withOpacity(.11),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: Text(post.tag, style: theme.textTheme.labelSmall?.copyWith(color: post.color, fontWeight: FontWeight.w700)),
              ),
            ),
            const Divider(height: 22),
            Row(
              children: [
                _ActionButton(
                  icon: post.liked ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  label: '${post.likes}',
                  color: post.liked ? Colors.pinkAccent : null,
                  onTap: onLike,
                ),
                const SizedBox(width: 16),
                _ActionButton(icon: Icons.chat_bubble_outline_rounded, label: 'Responder', onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Los comentarios estarán disponibles al activar el backend.')),
                  );
                }),
                const Spacer(),
                IconButton(
                  tooltip: post.saved ? 'Quitar de guardados' : 'Guardar',
                  visualDensity: VisualDensity.compact,
                  onPressed: onSave,
                  icon: Icon(post.saved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded,
                      color: post.saved ? theme.colorScheme.primary : null),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({required this.icon, required this.label, this.onTap, this.color});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 19, color: color ?? Theme.of(context).colorScheme.onSurface.withOpacity(.68)),
            const SizedBox(width: 6),
            Text(label, style: Theme.of(context).textTheme.labelMedium?.copyWith(color: color)),
          ]),
        ),
      );
}

class _MediaChip extends StatelessWidget {
  const _MediaChip({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) => Chip(
        avatar: Icon(icon, size: 17),
        label: Text(label),
        visualDensity: VisualDensity.compact,
      );
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title, required this.subtitle, this.action});
  final String title;
  final String subtitle;
  final Widget? action;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 14),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(subtitle, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(.62))),
        ])),
        if (action != null) action!,
      ]),
    );
  }
}

class _GamesPage extends StatefulWidget {
  const _GamesPage();

  @override
  State<_GamesPage> createState() => _GamesPageState();
}

class _GamesPageState extends State<_GamesPage> {
  final List<(String, String, String, IconData, Color, String)> _games = [
    ('Órbita', 'LunaDev', 'Rompecabezas', Icons.public_rounded, const Color(0xFF7166F9), 'Aprobado'),
    ('Bosque de píxeles', 'pixelmara', 'Aventura', Icons.forest_rounded, const Color(0xFF36A981), 'Aprobado'),
    ('Neon Drift', 'Leo Vargas', 'Arcade', Icons.bolt_rounded, const Color(0xFFF39B45), 'En revisión'),
  ];

  Future<void> _submitGame() async {
    final title = TextEditingController();
    final description = TextEditingController();
    final url = TextEditingController();
    final result = await showModalBottomSheet<(String, String)?>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => Padding(
        padding: EdgeInsets.fromLTRB(20, 8, 20, MediaQuery.of(sheetContext).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('Enviar un juego', style: Theme.of(sheetContext).textTheme.titleLarge),
          const SizedBox(height: 8),
          const Text('Los juegos de la comunidad pasan por revisión antes de aparecer en la biblioteca.'),
          const SizedBox(height: 16),
          TextField(controller: title, maxLength: 100, decoration: const InputDecoration(labelText: 'Nombre del juego')),
          const SizedBox(height: 10),
          TextField(controller: description, maxLength: 500, decoration: const InputDecoration(labelText: 'Descripción')),
          const SizedBox(height: 10),
          TextField(controller: url, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Enlace del juego')),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () {
              if (title.text.trim().isEmpty || url.text.trim().isEmpty) return;
              Navigator.pop(sheetContext, (title.text.trim(), description.text.trim()));
            },
            icon: const Icon(Icons.send_rounded),
            label: const Text('Enviar a revisión'),
          ),
        ]),
      ),
    );
    title.dispose();
    description.dispose();
    url.dispose();
    if (!mounted || result == null) return;
    setState(() => _games.insert(0, (
      result.$1,
      'Tú',
      result.$2.isEmpty ? 'Creación de la comunidad' : result.$2,
      Icons.videogame_asset_rounded,
      const Color(0xFF7181EB),
      'En revisión',
    )));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Solicitud añadida a la cola demo; la revisión real requiere backend.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        _SectionHeader(
          title: 'Juegos',
          subtitle: 'Descubre creaciones de la comunidad.',
          action: IconButton(onPressed: _submitGame, icon: const Icon(Icons.add_rounded), tooltip: 'Enviar juego'),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: theme.colorScheme.primary.withOpacity(.09),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Row(children: [
              Icon(Icons.verified_user_outlined),
              SizedBox(width: 10),
              Expanded(child: Text('Los juegos de la comunidad se revisan antes de publicarse.', style: TextStyle(height: 1.35))),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        for (final game in _games)
          Card(
            margin: const EdgeInsets.fromLTRB(16, 5, 16, 9),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(color: game.$5.withOpacity(.15), borderRadius: BorderRadius.circular(17)),
                  child: Icon(game.$4, color: game.$5, size: 30),
                ),
                const SizedBox(width: 13),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(game.$1, style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 3),
                  Text('${game.$3} · por ${game.$2}', style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(.62))),
                  const SizedBox(height: 7),
                  Text(game.$6, style: theme.textTheme.labelSmall?.copyWith(
                    color: game.$6 == 'Aprobado' ? const Color(0xFF269B70) : const Color(0xFFE29431),
                    fontWeight: FontWeight.w700,
                  )),
                ])),
                IconButton(
                  onPressed: game.$6 == 'Aprobado' ? () => _showPrototypeNotice(context) : null,
                  icon: const Icon(Icons.play_circle_outline_rounded),
                  tooltip: game.$6 == 'Aprobado' ? 'Abrir juego' : 'Pendiente de aprobación',
                ),
              ]),
            ),
          ),
      ],
    );
  }
}

class _ChatPage extends StatelessWidget {
  const _ChatPage();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final chats = [
      ('Camila Torres', '¡Gracias por compartir tu proyecto!', '2 min', Icons.face_rounded, const Color(0xFFEC8A78), true),
      ('Equipo creativo', 'Mara: nos vemos en la sala', '18 min', Icons.groups_rounded, const Color(0xFF7189E8), true),
      ('Diego M.', 'Te mandé el boceto actualizado', '1 h', Icons.person_rounded, const Color(0xFF36A981), false),
      ('Nora Salas', '¡Qué buen juego!', '3 h', Icons.person_rounded, const Color(0xFFC27BE5), false),
    ];
    return ListView(
      padding: const EdgeInsets.only(bottom: 20),
      children: [
        _SectionHeader(
          title: 'Mensajes',
          subtitle: 'Conversaciones de tu comunidad.',
          action: IconButton(onPressed: () => _showPrototypeNotice(context), icon: const Icon(Icons.edit_outlined), tooltip: 'Nuevo mensaje'),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Buscar conversaciones',
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: theme.colorScheme.surface,
            ),
          ),
        ),
        const SizedBox(height: 8),
        for (final chat in chats)
          ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 7),
            leading: CircleAvatar(
              radius: 25,
              backgroundColor: chat.$5.withOpacity(.17),
              child: Icon(chat.$4, color: chat.$5),
            ),
            title: Text(chat.$1, style: theme.textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(chat.$2, maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(chat.$3, style: theme.textTheme.labelSmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(.58))),
              if (chat.$6) ...[
                const SizedBox(height: 7),
                Container(width: 8, height: 8, decoration: BoxDecoration(color: theme.colorScheme.primary, shape: BoxShape.circle)),
              ],
            ]),
            onTap: () => showDialog<void>(
              context: context,
              builder: (dialogContext) => AlertDialog(
                title: Text(chat.$1),
                content: const Text('La mensajería es una vista de muestra. Al conectar Supabase se podrá enviar y recibir mensajes reales.'),
                actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Entendido'))],
              ),
            ),
          ),
        const SizedBox(height: 12),
        const Padding(
          padding: EdgeInsets.all(20),
          child: Text('Privacidad primero: las conversaciones reales solo serán visibles para sus participantes.', textAlign: TextAlign.center),
        ),
      ],
    );
  }
}

class _InsightsPage extends StatelessWidget {
  const _InsightsPage();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        const _SectionHeader(title: 'Tu actividad', subtitle: 'Un vistazo a lo que compartes y descubres.'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            Expanded(child: _MetricCard(icon: Icons.favorite_outline_rounded, label: 'Me gusta', value: '128', delta: '+18%', color: const Color(0xFFEA7891))),
            const SizedBox(width: 10),
            Expanded(child: _MetricCard(icon: Icons.visibility_outlined, label: 'Vistas', value: '1.4k', delta: '+12%', color: const Color(0xFF7281EB))),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
          child: Row(children: [
            Expanded(child: _MetricCard(icon: Icons.chat_bubble_outline_rounded, label: 'Respuestas', value: '36', delta: '+8%', color: const Color(0xFF35A98D))),
            const SizedBox(width: 10),
            Expanded(child: _MetricCard(icon: Icons.bookmark_border_rounded, label: 'Guardados', value: '22', delta: '+5%', color: const Color(0xFFE6A044))),
          ]),
        ),
        Card(
          margin: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Interacción esta semana', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('Actividad diaria · datos de ejemplo', style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurface.withOpacity(.6))),
              const SizedBox(height: 20),
              SizedBox(height: 150, width: double.infinity, child: CustomPaint(painter: _ChartPainter(color: theme.colorScheme.primary, grid: theme.dividerColor.withOpacity(.35)))),
              const SizedBox(height: 10),
              const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text('Lun'), Text('Mar'), Text('Mié'), Text('Jue'), Text('Vie'), Text('Sáb'), Text('Dom'),
              ]),
            ]),
          ),
        ),
        Card(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Icon(Icons.lightbulb_outline_rounded, color: theme.colorScheme.primary),
              const SizedBox(width: 12),
              const Expanded(child: Text('Tus publicaciones creativas reciben más respuestas por la tarde.', style: TextStyle(height: 1.4))),
            ]),
          ),
        ),
      ],
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.icon, required this.label, required this.value, required this.delta, required this.color});
  final IconData icon;
  final String label;
  final String value;
  final String delta;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 12),
          Text(value, style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Row(children: [
            Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: theme.textTheme.labelMedium?.copyWith(color: theme.colorScheme.onSurface.withOpacity(.65)))),
            Text(delta, style: theme.textTheme.labelSmall?.copyWith(color: const Color(0xFF269B70), fontWeight: FontWeight.w700)),
          ]),
        ]),
      ),
    );
  }
}

class _ChartPainter extends CustomPainter {
  const _ChartPainter({required this.color, required this.grid});
  final Color color;
  final Color grid;

  @override
  void paint(Canvas canvas, Size size) {
    final gridPaint = Paint()..color = grid..strokeWidth = 1;
    for (var row = 0; row < 4; row++) {
      final y = size.height * row / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), gridPaint);
    }
    final points = <Offset>[
      Offset(0, size.height * .72),
      Offset(size.width * .16, size.height * .62),
      Offset(size.width * .33, size.height * .69),
      Offset(size.width * .50, size.height * .40),
      Offset(size.width * .67, size.height * .48),
      Offset(size.width * .83, size.height * .27),
      Offset(size.width, size.height * .18),
    ];
    final path = Path()..moveTo(points.first.dx, points.first.dy);
    for (var i = 0; i < points.length - 1; i++) {
      final current = points[i];
      final next = points[i + 1];
      final middleX = (current.dx + next.dx) / 2;
      path.cubicTo(middleX, current.dy, middleX, next.dy, next.dx, next.dy);
    }
    final fillPath = Path.from(path)
      ..lineTo(size.width, size.height)
      ..lineTo(0, size.height)
      ..close();
    canvas.drawPath(fillPath, Paint()..shader = LinearGradient(
      colors: [color.withOpacity(.23), color.withOpacity(0)],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    ).createShader(Offset.zero & size));
    canvas.drawPath(path, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 3..strokeCap = StrokeCap.round);
    for (final point in points) {
      canvas.drawCircle(point, 4, Paint()..color = color);
      canvas.drawCircle(point, 2, Paint()..color = Colors.white);
    }
  }

  @override
  bool shouldRepaint(covariant _ChartPainter oldDelegate) => color != oldDelegate.color || grid != oldDelegate.grid;
}

class _AdminPage extends StatelessWidget {
  const _AdminPage();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return ListView(
      padding: const EdgeInsets.only(bottom: 24),
      children: [
        const _SectionHeader(title: 'Administración', subtitle: 'Moderación y salud de la comunidad.'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFFE6A044).withOpacity(.13), borderRadius: BorderRadius.circular(16)),
            child: const Row(children: [
              Icon(Icons.info_outline_rounded, color: Color(0xFFE6A044)),
              SizedBox(width: 10),
              Expanded(child: Text('Panel de ejemplo. El acceso real debe limitarse a administradores autorizados en el servidor.')),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            Expanded(child: _MetricCard(icon: Icons.people_outline, label: 'Usuarios activos', value: '284', delta: '+9%', color: theme.colorScheme.primary)),
            const SizedBox(width: 10),
            Expanded(child: _MetricCard(icon: Icons.flag_outlined, label: 'Reportes', value: '7', delta: '3 nuevos', color: const Color(0xFFE6A044))),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18),
          child: Text('Pendiente de revisión', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
        ),
        for (final item in [
          ('Neon Drift', 'Juego enviado por Leo Vargas', Icons.sports_esports_outlined),
          ('Publicación reportada', '2 reportes · revisión requerida', Icons.flag_outlined),
          ('Bosque sonoro', 'Juego enviado por Ana P.', Icons.videogame_asset_outlined),
        ])
          Card(
            margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: ListTile(
              leading: CircleAvatar(backgroundColor: theme.colorScheme.primary.withOpacity(.1), child: Icon(item.$3, color: theme.colorScheme.primary)),
              title: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(item.$2),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => showModalBottomSheet<void>(
                context: context,
                showDragHandle: true,
                builder: (sheetContext) => SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
                    child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      Text(item.$1, style: Theme.of(sheetContext).textTheme.titleLarge),
                      const SizedBox(height: 8),
                      const Text('En la versión conectada, un administrador revisará el contenido y registrará su decisión.'),
                      const SizedBox(height: 18),
                      FilledButton(onPressed: () { Navigator.pop(sheetContext); _showPrototypeNotice(context); }, child: const Text('Aprobar (demo)')),
                      OutlinedButton(onPressed: () { Navigator.pop(sheetContext); _showPrototypeNotice(context); }, child: const Text('Rechazar (demo)')),
                    ]),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

void _showPrototypeNotice(BuildContext context) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text('Esta acción es de demostración; requiere conectar el backend y controlar permisos.')),
  );
}
