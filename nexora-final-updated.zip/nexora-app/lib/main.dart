import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'app.dart';
import 'core/constants.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  await Hive.initFlutter();
  await Hive.openBox('settings');
  await Hive.openBox('theme');

  var supabaseReady = false;
  if (Constants.hasSupabaseCredentials) {
    try {
      await Supabase.initialize(
        url: Constants.supabaseUrl,
        anonKey: Constants.supabaseAnonKey,
      );
      supabaseReady = true;
    } catch (error) {
      debugPrint('No se pudo iniciar Supabase: $error');
    }
  }

  runApp(
    ProviderScope(
      child: NexoraApp(supabaseReady: supabaseReady),
    ),
  );
}
