-- NEXORA · Esquema inicial para Supabase/PostgreSQL
-- Ejecutar una vez en un proyecto NUEVO desde el SQL Editor.
-- Los datos de feed/juegos de la app Flutter aún son de demostración.

create extension if not exists "uuid-ossp";

-- -----------------------------------------------------------------------------
-- Tablas
-- -----------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  username text unique not null,
  display_name text not null default 'Usuario',
  bio text not null default '',
  avatar_url text,
  role text not null default 'user' check (role in ('user', 'admin')),
  is_banned boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null default '' check (char_length(content) <= 1000),
  media_url text,
  media_type text check (media_type in ('image', 'video', 'pdf', 'animation', 'other')),
  thumbnail_url text,
  allow_download boolean not null default false,
  likes_count integer not null default 0 check (likes_count >= 0),
  reposts_count integer not null default 0 check (reposts_count >= 0),
  saves_count integer not null default 0 check (saves_count >= 0),
  is_approved boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint posts_content_or_media check (content <> '' or media_url is not null)
);

create table if not exists public.likes (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

create table if not exists public.reposts (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

create table if not exists public.saves (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

create table if not exists public.follows (
  id uuid primary key default uuid_generate_v4(),
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.conversations (
  id uuid primary key default uuid_generate_v4(),
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_participants (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default uuid_generate_v4(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 4000),
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.games (
  id uuid primary key default uuid_generate_v4(),
  title text not null check (char_length(title) between 1 and 100),
  description text not null default '' check (char_length(description) <= 2000),
  cover_url text,
  game_url text not null,
  created_by uuid references public.profiles(id) on delete set null,
  is_official boolean not null default false,
  is_approved boolean not null default false,
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default uuid_generate_v4(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete cascade,
  reason text not null check (reason in ('inappropriate', 'harassment', 'spam', 'misinformation', 'other')),
  details text not null default '' check (char_length(details) <= 1000),
  status text not null default 'pending' check (status in ('pending', 'reviewing', 'resolved', 'dismissed')),
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  constraint reports_target_required check (post_id is not null or reported_user_id is not null)
);

-- -----------------------------------------------------------------------------
-- Índices
-- -----------------------------------------------------------------------------
create index if not exists posts_user_id_idx on public.posts(user_id);
create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_approved_created_idx on public.posts(is_approved, created_at desc);
create index if not exists likes_post_id_idx on public.likes(post_id);
create index if not exists follows_follower_id_idx on public.follows(follower_id);
create index if not exists follows_following_id_idx on public.follows(following_id);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at desc);
create index if not exists reports_pending_created_idx on public.reports(status, created_at desc);
create index if not exists games_review_queue_idx on public.games(is_approved, created_at desc);

-- -----------------------------------------------------------------------------
-- Funciones auxiliares con search_path explícito
-- -----------------------------------------------------------------------------
create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and is_banned = false
  );
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and is_banned = false
  );
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, username, display_name)
  values (
    new.id,
    'user_' || substr(replace(new.id::text, '-', ''), 1, 12),
    coalesce(nullif(trim(new.raw_user_meta_data->>'display_name'), ''), 'Usuario')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists posts_set_updated_at on public.posts;
create trigger posts_set_updated_at before update on public.posts
for each row execute function public.set_updated_at();

-- Crear una conversación directa con otro usuario sin permitir autoañadirse a chats ajenos.
create or replace function public.is_conversation_participant(target_conversation_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.conversation_participants
    where conversation_id = target_conversation_id and user_id = auth.uid()
  );
$$;

create or replace function public.start_conversation(other_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  new_conversation_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Debes iniciar sesión.';
  end if;
  if other_user_id is null or other_user_id = auth.uid() then
    raise exception 'Destinatario no válido.';
  end if;
  if not exists (select 1 from public.profiles where id = other_user_id and is_banned = false) then
    raise exception 'El usuario no está disponible.';
  end if;

  insert into public.conversations default values returning id into new_conversation_id;
  insert into public.conversation_participants (conversation_id, user_id)
  values (new_conversation_id, auth.uid()), (new_conversation_id, other_user_id);
  return new_conversation_id;
end;
$$;

-- Los cambios de aprobación requieren un administrador; los clientes no reciben permiso directo.
create or replace function public.review_game(target_game_id uuid, approve boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'Solo administradores pueden revisar juegos.' using errcode = '42501';
  end if;
  update public.games
     set is_approved = approve,
         reviewed_by = auth.uid(),
         reviewed_at = now()
   where id = target_game_id;
  if not found then
    raise exception 'No se encontró el juego.';
  end if;
end;
$$;

-- Cambiar el estado de una cuenta solo mediante una operación administrativa.
create or replace function public.admin_set_user_banned(target_user_id uuid, should_ban boolean)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'Solo administradores pueden cambiar el estado de usuarios.' using errcode = '42501';
  end if;
  if target_user_id = auth.uid() and should_ban then
    raise exception 'No puedes suspender tu propia cuenta.';
  end if;
  update public.profiles set is_banned = should_ban where id = target_user_id;
  if not found then
    raise exception 'No se encontró el usuario.';
  end if;
end;
$$;

-- -----------------------------------------------------------------------------
-- Row Level Security
-- -----------------------------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.reposts enable row level security;
alter table public.saves enable row level security;
alter table public.follows enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_participants enable row level security;
alter table public.messages enable row level security;
alter table public.games enable row level security;
alter table public.reports enable row level security;

-- Quitar las políticas de esta versión antes de crearlas permite volver a ejecutar el script.
drop policy if exists "Perfiles públicos visibles" on public.profiles;
drop policy if exists "Usuario puede editar su perfil" on public.profiles;
drop policy if exists "Admin puede editar perfiles" on public.profiles;
drop policy if exists "Posts aprobados visibles" on public.posts;
drop policy if exists "Usuario puede crear posts" on public.posts;
drop policy if exists "Usuario puede editar sus posts" on public.posts;
drop policy if exists "Usuario puede borrar sus posts" on public.posts;
drop policy if exists "Likes visibles" on public.likes;
drop policy if exists "Usuario gestiona sus likes" on public.likes;
drop policy if exists "Reposts visibles" on public.reposts;
drop policy if exists "Usuario gestiona sus reposts" on public.reposts;
drop policy if exists "Usuario ve sus guardados" on public.saves;
drop policy if exists "Usuario gestiona sus guardados" on public.saves;
drop policy if exists "Seguimientos visibles" on public.follows;
drop policy if exists "Usuario gestiona sus seguimientos" on public.follows;
drop policy if exists "Participantes ven conversaciones" on public.conversations;
drop policy if exists "Participantes ven integrantes" on public.conversation_participants;
drop policy if exists "Participantes ven mensajes" on public.messages;
drop policy if exists "Participante envía mensaje" on public.messages;
drop policy if exists "Juegos aprobados visibles" on public.games;
drop policy if exists "Usuario envía juego" on public.games;
drop policy if exists "Usuario edita juego pendiente" on public.games;
drop policy if exists "Admin revisa juegos" on public.games;
drop policy if exists "Usuario crea reporte" on public.reports;
drop policy if exists "Usuario ve sus reportes" on public.reports;
drop policy if exists "Admin gestiona reportes" on public.reports;

create policy "Perfiles públicos visibles" on public.profiles
  for select to anon, authenticated using (is_banned = false or id = auth.uid() or public.is_admin());
create policy "Usuario puede editar su perfil" on public.profiles
  for update to authenticated using (auth.uid() = id and is_banned = false)
  with check (auth.uid() = id and is_banned = false);
create policy "Admin puede editar perfiles" on public.profiles
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
-- Impide que un usuario se eleve a admin o se quite el estado de ban mediante update REST.
revoke update on public.profiles from authenticated;
grant update (username, display_name, bio, avatar_url) on public.profiles to authenticated;
revoke update on public.posts from authenticated;
grant update (content, media_url, media_type, thumbnail_url, allow_download) on public.posts to authenticated;

create policy "Posts aprobados visibles" on public.posts
  for select to anon, authenticated using (is_approved = true or auth.uid() = user_id or public.is_admin());
create policy "Usuario puede crear posts" on public.posts
  for insert to authenticated with check (
    auth.uid() = user_id and exists (select 1 from public.profiles p where p.id = auth.uid() and not p.is_banned)
  );
create policy "Usuario puede editar sus posts" on public.posts
  for update to authenticated using (auth.uid() = user_id and public.is_admin() = false)
  with check (auth.uid() = user_id);
create policy "Usuario puede borrar sus posts" on public.posts
  for delete to authenticated using (auth.uid() = user_id or public.is_admin());

create policy "Likes visibles" on public.likes
  for select to authenticated using (true);
create policy "Usuario gestiona sus likes" on public.likes
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Reposts visibles" on public.reposts
  for select to authenticated using (true);
create policy "Usuario gestiona sus reposts" on public.reposts
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Usuario ve sus guardados" on public.saves
  for select to authenticated using (auth.uid() = user_id);
create policy "Usuario gestiona sus guardados" on public.saves
  for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy "Seguimientos visibles" on public.follows
  for select to authenticated using (true);
create policy "Usuario gestiona sus seguimientos" on public.follows
  for all to authenticated using (auth.uid() = follower_id)
  with check (auth.uid() = follower_id and follower_id <> following_id and public.is_active_user());

create policy "Participantes ven conversaciones" on public.conversations
  for select to authenticated using (
    public.is_conversation_participant(id)
  );
create policy "Participantes ven integrantes" on public.conversation_participants
  for select to authenticated using (
    public.is_conversation_participant(conversation_id)
  );
create policy "Participantes ven mensajes" on public.messages
  for select to authenticated using (
    public.is_conversation_participant(conversation_id)
  );
create policy "Participante envía mensaje" on public.messages
  for insert to authenticated with check (
    auth.uid() = sender_id and public.is_active_user()
    and public.is_conversation_participant(conversation_id)
  );

create policy "Juegos aprobados visibles" on public.games
  for select to anon, authenticated using (is_approved = true or auth.uid() = created_by or public.is_admin());
create policy "Usuario envía juego" on public.games
  for insert to authenticated with check (
    auth.uid() = created_by and public.is_active_user()
    and is_approved = false and is_official = false
    and reviewed_by is null and reviewed_at is null
  );
create policy "Usuario edita juego pendiente" on public.games
  for update to authenticated using (auth.uid() = created_by and is_approved = false)
  with check (auth.uid() = created_by and is_approved = false and is_official = false);
create policy "Admin revisa juegos" on public.games
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
revoke update on public.games from authenticated;
grant update (title, description, cover_url, game_url) on public.games to authenticated;

create policy "Usuario crea reporte" on public.reports
  for insert to authenticated with check (
    auth.uid() = reporter_id and public.is_active_user() and status = 'pending'
    and reviewed_by is null and reviewed_at is null
  );
create policy "Usuario ve sus reportes" on public.reports
  for select to authenticated using (auth.uid() = reporter_id);
create policy "Admin gestiona reportes" on public.reports
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- Acceso a funciones RPC; la autorización sensible se vuelve a comprobar dentro de cada función.
grant execute on function public.start_conversation(uuid) to authenticated;
grant execute on function public.review_game(uuid, boolean) to authenticated;
grant execute on function public.admin_set_user_banned(uuid, boolean) to authenticated;
