# Nexora

**Tu espacio. Tus reglas.**

Nexora es un prototipo Flutter de comunidad para compartir publicaciones y proyectos, conversar y descubrir juegos. Este paquete contiene una interfaz navegable y un esquema inicial para Supabase; aún no es una red social lista para producción.

## Lo que incluye esta versión

- Arranque seguro cuando Supabase todavía no está configurado.
- Registro, inicio de sesión y recuperación de contraseña al conectar Supabase.
- Feed demostrativo con crear publicación local, me gusta, guardar y reportar.
- Compositor que muestra los formatos previstos: imagen, video, PDF y juego.
- Biblioteca de juegos con estado de aprobación y formulario demo para enviar un proyecto a revisión.
- Vistas de chat, analítica con gráficas y panel administrativo ampliado (ban usuarios, ban IP, reportes, aprobación de juegos).
- Cambio entre tema claro y oscuro con preferencias guardadas localmente.
- Esquema SQL con perfiles, publicaciones, interacciones, seguimientos, chats privados, juegos pendientes y reportes, junto con políticas RLS iniciales.

## Importante: modo prototipo

El feed, los mensajes, los juegos y las métricas de las pantallas son datos de muestra. Las publicaciones y solicitudes creadas desde esas pantallas solo viven durante la sesión de la aplicación. El botón de medios todavía no selecciona ni sube archivos. La mensajería no está conectada a Realtime y el panel administrativo no concede permisos reales.

El esquema SQL es una base de desarrollo, no una auditoría de seguridad ni una configuración lista para producción. Debe revisarse y probarse en un proyecto Supabase de pruebas antes de usar datos reales. No incluyas nunca una clave `service_role` en Flutter; utiliza únicamente la clave pública anon/publishable y políticas RLS.

## Ejecutar

1. Instala Flutter siguiendo la guía oficial: <https://docs.flutter.dev/get-started/install>.
2. Crea un proyecto de prueba en <https://supabase.com>.
3. Copia la URL del proyecto y la clave pública anon/publishable en `lib/core/constants.dart`.
4. Ejecuta `supabase/schema.sql` desde el SQL Editor de un proyecto nuevo.
5. Desde la carpeta del proyecto, ejecuta:

   ```sh
   flutter pub get
   flutter analyze
   flutter test
   flutter run
   ```

Sin credenciales válidas, la app abre con modo demo y permite explorar las pantallas. Con Supabase configurado, se activan los flujos de autenticación; el resto de módulos requiere conectar consultas y almacenamiento antes de usarse como datos reales.

## Próximas etapas recomendadas

1. Añadir pruebas de permisos RLS y crear una cuenta administradora de forma segura.
2. Conectar el feed, perfiles, likes, guardados, seguimientos y reportes a Supabase.
3. Añadir subida de medios a Storage, límites de tamaño y validación de tipos.
4. Conectar chat a Realtime y probar que solo los participantes vean las conversaciones.
5. Construir moderación real con RPC/Edge Functions y auditoría de decisiones (ya existen admin_set_user_banned, admin_ban_ip y admin_unban_ip).
6. Calcular analítica desde eventos reales y permitir exportar los datos del usuario.
7. Ejecutar `flutter analyze`, pruebas unitarias, integración en Android/iOS y revisión de accesibilidad.

## Versión web (GitHub Pages)

La carpeta `web/` es un sitio estático sin dependencias (HTML + CSS + JS, sin librerías externas):
`index.html` (app), `legal.html` (privacidad, cookies y términos) y `.nojekyll`.

1. Sube el repositorio a GitHub.
2. Settings → Pages → Branch `main`, carpeta `/web`.
3. Opcional: pega tu URL y clave **pública** anon de Supabase en la constante `SB` de `web/index.html`.

Completa los datos del responsable en `web/legal.html` y revísalo con un profesional antes de usar datos reales.

### Versión final web: pasos

1. Supabase → SQL Editor: ejecuta `supabase/schema.sql` y después `supabase/schema_v2.sql`.
2. Pega URL y clave pública anon en `web/config.js`.
3. Sube a GitHub en la rama `main`; el workflow `.github/workflows/pages.yml` publica `web/` (activa Settings → Pages → Source: GitHub Actions).
4. Para tu rol admin: en Supabase ejecuta `update public.profiles set role='admin' where username='tu_usuario';`
5. Menú lateral: en móvil se abre deslizando desde el borde izquierdo; deslizar desde el borde derecho abre Ajustes. Es instalable como app (PWA).


## Administradores (solo con Gmail / email autorizado)

Los administradores **no** se eligen desde la app. Tú los defines en Supabase:

```sql
-- Después de que el admin se registre con su Gmail:
update public.profiles
set role = 'admin'
where id = (select id from auth.users where email = 'tu-admin@gmail.com');
```

- Solo las cuentas con `role = 'admin'` ven la pestaña **Admin**.
- Los usuarios normales **nunca** ven funciones de administración (ni la pestaña, ni botones de ban, reportes de moderación, etc.).
- Puedes tener hasta 3 administradores (o los que quieras).
- Funciona con cualquier email; Gmail es el más habitual.

## Generar APK (Android)

```bash
flutter pub get
flutter build apk --release
```

El archivo queda en `build/app/outputs/flutter-apk/app-release.apk`.

Para Windows: `flutter build windows`  
Para iOS: `flutter build ipa` (requiere Mac).

## Analítica

La pantalla de Analítica muestra métricas de actividad. Cuando Supabase está configurado y hay datos reales, las consultas se preparan para leer likes, publicaciones y reportes. En modo demo usa valores de ejemplo.
