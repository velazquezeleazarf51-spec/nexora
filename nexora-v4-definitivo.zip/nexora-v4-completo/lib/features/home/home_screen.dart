import 'dart:io';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';
import 'package:video_player/video_player.dart';

import '../../core/constants.dart';
import '../../core/providers/profile_provider.dart';
import '../../theme/theme_provider.dart';
import '../auth/presentation/login_screen.dart';
import '../stories/stories_strip.dart';
import '../chat/chat_media_page.dart';

class FeedPost {
  FeedPost({
    required this.author,
    required this.handle,
    required this.time,
    required this.text,
    required this.tag,
    required this.color,
    required this.likes,
    this.id,
    this.mediaUrl,
    this.mediaType,
    this.allowDownload = false,
    this.hashtags = const [],
    this.liked = false,
    this.saved = false,
    this.remote = false,
  });
  final String? id;
  final String author, handle, time, text, tag;
  final Color color;
  final String? mediaUrl, mediaType;
  final bool allowDownload;
  final List<String> hashtags;
  int likes;
  bool liked, saved;
  final bool remote;
}

class AppSection {
  AppSection({required this.title, required this.description, required this.routeKey, this.icon = 'apps'});
  final String title, description, routeKey, icon;
}

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key, this.supabaseReady = true, this.isDemo = false, this.displayName = 'Usuario'});
  final bool supabaseReady, isDemo;
  final String displayName;
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _index = 0;
  bool _loadingFeed = false;
  int _likesCount = 0, _postsCount = 0, _savesCount = 0, _reportsCount = 0;
  bool _analyticsFromServer = false;
  late List<FeedPost> _posts;
  List<AppSection> _extraSections = [];
  String? _filterHashtag;

  static const _base = [
    _Dest('Inicio', Icons.home_rounded, Icons.home_outlined),
    _Dest('Juegos', Icons.sports_esports_rounded, Icons.sports_esports_outlined),
    _Dest('Chat', Icons.chat_bubble_rounded, Icons.chat_bubble_outline_rounded),
    _Dest('Analítica', Icons.insights_rounded, Icons.insights_outlined),
  ];
  static const _adminDest = _Dest('Admin', Icons.admin_panel_settings_rounded, Icons.admin_panel_settings_outlined);

  @override
  void initState() {
    super.initState();
    _posts = _demoPosts();
    if (widget.supabaseReady && !widget.isDemo) {
      _loadFeed();
      _loadAnalytics();
      _loadSections();
    }
  }

  List<FeedPost> _demoPosts() => [
        FeedPost(author: 'Sofía Martínez', handle: '@sofia.crea', time: 'hace 12 min', text: 'Ilustración terminada #arte #ilustracion', tag: 'Ilustración', color: const Color(0xFF8B7CF6), likes: 28, hashtags: ['arte', 'ilustracion'], allowDownload: true, mediaType: 'image'),
        FeedPost(author: 'Leo Vargas', handle: '@leo_juega', time: 'hace 38 min', text: 'Minijuego listo. Feedback? #juegos #indie', tag: 'Proyecto', color: const Color(0xFF29B6A5), likes: 16, hashtags: ['juegos', 'indie']),
        FeedPost(author: 'Mara Ríos', handle: '@mararios', time: 'hace 1 h', text: 'Tu espacio creativo es único. #comunidad', tag: 'Comunidad', color: const Color(0xFFFF9C70), likes: 43, hashtags: ['comunidad']),
      ];

  void _toast(String m) {
    ScaffoldMessenger.of(context)..hideCurrentSnackBar()..showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));
  }

  Future<void> _signOut() async {
    try { await ref.read(authProvider.notifier).signOut(); } catch (_) {}
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
  }

  List<String> _extractTags(String text) {
    final re = RegExp(r'#([a-zA-Z0-9_]{1,40})');
    return re.allMatches(text).map((m) => m.group(1)!.toLowerCase()).toSet().toList();
  }

  Future<void> _loadFeed({String? tag}) async {
    if (!Constants.hasSupabaseCredentials) return;
    setState(() => _loadingFeed = true);
    try {
      final client = Supabase.instance.client;
      var query = client.from('posts').select(
        'id, content, likes_count, created_at, media_type, media_url, allow_download, hashtags, profiles(display_name, username)',
      ).eq('is_approved', true);
      final rows = await query.order('created_at', ascending: false).limit(50);
      final list = <FeedPost>[];
      for (final r in (rows as List)) {
        final p = r['profiles'] as Map<String, dynamic>?;
        final tags = (r['hashtags'] as List?)?.map((e) => e.toString()).toList() ?? <String>[];
        if (tag != null && tag.isNotEmpty && !tags.map((e) => e.toLowerCase()).contains(tag.toLowerCase())) continue;
        list.add(FeedPost(
          id: r['id'] as String?,
          author: p?['display_name'] as String? ?? 'Usuario',
          handle: '@${p?['username'] ?? 'user'}',
          time: _ago(r['created_at'] as String?),
          text: (r['content'] as String?) ?? '',
          tag: (r['media_type'] as String?) ?? 'Texto',
          color: const Color(0xFF8B7CF6),
          likes: (r['likes_count'] as int?) ?? 0,
          mediaUrl: r['media_url'] as String?,
          mediaType: r['media_type'] as String?,
          allowDownload: r['allow_download'] as bool? ?? false,
          hashtags: tags,
          remote: true,
        ));
      }
      if (mounted) setState(() { if (list.isNotEmpty || tag != null) _posts = list; _loadingFeed = false; });
    } catch (e) {
      debugPrint('Feed: $e');
      if (mounted) setState(() => _loadingFeed = false);
    }
  }

  Future<void> _loadAnalytics() async {
    if (!Constants.hasSupabaseCredentials) return;
    try {
      final c = Supabase.instance.client;
      final uid = c.auth.currentUser?.id;
      if (uid == null) return;
      final posts = await c.from('posts').select('id').eq('user_id', uid);
      final likes = await c.from('likes').select('id').eq('user_id', uid);
      final saves = await c.from('saves').select('id').eq('user_id', uid);
      int reports = 0;
      try { reports = ((await c.from('reports').select('id').eq('status', 'pending')) as List).length; } catch (_) {}
      if (mounted) {
        setState(() {
          _postsCount = (posts as List).length;
          _likesCount = (likes as List).length;
          _savesCount = (saves as List).length;
          _reportsCount = reports;
          _analyticsFromServer = true;
        });
      }
    } catch (e) { debugPrint('Analytics: $e'); }
  }

  Future<void> _loadSections() async {
    if (!Constants.hasSupabaseCredentials) return;
    try {
      final rows = await Supabase.instance.client.from('app_sections').select().eq('is_visible', true).order('sort_order');
      final extra = <AppSection>[];
      for (final r in (rows as List)) {
        final key = r['route_key'] as String? ?? '';
        if (const {'home', 'games', 'chat', 'analytics', 'admin'}.contains(key)) continue;
        extra.add(AppSection(
          title: r['title'] as String? ?? 'Sección',
          description: r['description'] as String? ?? '',
          routeKey: key,
          icon: r['icon'] as String? ?? 'apps',
        ));
      }
      if (mounted) setState(() => _extraSections = extra);
    } catch (e) { debugPrint('Sections: $e'); }
  }

  String _ago(String? iso) {
    if (iso == null) return '';
    try {
      final m = DateTime.now().difference(DateTime.parse(iso)).inMinutes;
      if (m < 1) return 'ahora';
      if (m < 60) return 'hace $m min';
      if (m < 1440) return 'hace ${m ~/ 60} h';
      return 'hace ${m ~/ 1440} d';
    } catch (_) { return ''; }
  }

  Future<void> _compose() async {
    final textCtrl = TextEditingController();
    final tagCtrl = TextEditingController();
    bool allowDownload = false;
    XFile? videoFile;
    int? videoSeconds;
    String? videoError;

    final result = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        return StatefulBuilder(builder: (ctx, setModal) {
          return Padding(
            padding: EdgeInsets.fromLTRB(20, 8, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text('Nueva publicación', style: Theme.of(ctx).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
                const SizedBox(height: 12),
                TextField(controller: textCtrl, maxLines: 4, maxLength: 1000, decoration: const InputDecoration(hintText: '¿Qué quieres compartir? Usa #temas', border: OutlineInputBorder())),
                const SizedBox(height: 8),
                TextField(controller: tagCtrl, decoration: const InputDecoration(hintText: 'Etiquetas extra (opcional): arte, juegos', prefixIcon: Icon(Icons.tag), border: OutlineInputBorder())),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: () async {
                    setModal(() { videoError = null; });
                    final picker = ImagePicker();
                    final file = await picker.pickVideo(source: ImageSource.gallery, maxDuration: Duration(minutes: Constants.maxVideoDurationMinutes));
                    if (file == null) return;
                    // Validar duración
                    try {
                      final controller = kIsWeb
                          ? VideoPlayerController.networkUrl(Uri.parse(file.path))
                          : VideoPlayerController.file(File(file.path));
                      await controller.initialize();
                      final dur = controller.value.duration;
                      await controller.dispose();
                      final secs = dur.inSeconds;
                      if (secs > Constants.maxVideoDurationMinutes * 60) {
                        setModal(() {
                          videoError = 'El video supera ${Constants.maxVideoDurationMinutes} minutos.';
                          videoFile = null;
                          videoSeconds = null;
                        });
                        return;
                      }
                      setModal(() { videoFile = file; videoSeconds = secs; videoError = null; });
                    } catch (e) {
                      // Si no se puede leer duración, aceptamos con aviso (límite del picker ya aplica maxDuration en muchos dispositivos)
                      setModal(() { videoFile = file; videoSeconds = null; videoError = null; });
                    }
                  },
                  icon: const Icon(Icons.videocam_outlined),
                  label: Text(videoFile == null ? 'Añadir video (máx. ${Constants.maxVideoDurationMinutes} min)' : 'Video listo${videoSeconds != null ? ' (${videoSeconds! ~/ 60}m ${videoSeconds! % 60}s)' : ''}'),
                ),
                if (videoError != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(videoError!, style: const TextStyle(color: Colors.redAccent, fontSize: 13))),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Permitir descarga'),
                  subtitle: const Text('Otros podrán descargar el archivo de esta publicación'),
                  value: allowDownload,
                  onChanged: (v) => setModal(() => allowDownload = v),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: () {
                    final body = textCtrl.text.trim();
                    if (body.isEmpty && videoFile == null) return;
                    Navigator.pop(ctx, {
                      'text': body,
                      'tags': tagCtrl.text.trim(),
                      'allowDownload': allowDownload,
                      'video': videoFile,
                      'seconds': videoSeconds,
                    });
                  },
                  icon: const Icon(Icons.send_rounded),
                  label: const Text('Publicar'),
                ),
              ]),
            ),
          );
        });
      },
    );
    textCtrl.dispose();
    tagCtrl.dispose();
    if (result == null) return;

    final body = result['text'] as String? ?? '';
    final extraTags = (result['tags'] as String? ?? '').split(RegExp(r'[,#\s]+')).where((e) => e.isNotEmpty).map((e) => e.toLowerCase()).toList();
    final tags = {..._extractTags(body), ...extraTags}.toList();
    final allow = result['allowDownload'] as bool? ?? false;
    final video = result['video'] as XFile?;
    final secs = result['seconds'] as int?;

    String? mediaUrl;
    String? mediaType;

    if (widget.supabaseReady && !widget.isDemo && Constants.hasSupabaseCredentials) {
      try {
        final client = Supabase.instance.client;
        final uid = client.auth.currentUser?.id;
        if (uid == null) throw Exception('Sin sesión');

        if (video != null) {
          final ext = video.name.split('.').last.toLowerCase();
          final path = '$uid/${const Uuid().v4()}.$ext';
          final bytes = await video.readAsBytes();
          await client.storage.from('media').uploadBinary(path, bytes, fileOptions: FileOptions(contentType: video.mimeType ?? 'video/mp4', upsert: true));
          mediaUrl = client.storage.from('media').getPublicUrl(path);
          mediaType = 'video';
        }

        final inserted = await client.from('posts').insert({
          'user_id': uid,
          'content': body,
          'is_approved': true,
          'allow_download': allow,
          'media_url': mediaUrl,
          'media_type': mediaType,
          'hashtags': tags,
          if (secs != null) 'duration_seconds': secs,
        }).select('id').single();

        final postId = inserted['id'] as String?;
        if (postId != null && tags.isNotEmpty) {
          try { await client.rpc('sync_post_hashtags', params: {'p_post_id': postId, 'p_tags': tags}); } catch (_) {}
        }
        _toast('Publicación guardada');
        await _loadFeed(tag: _filterHashtag);
        await _loadAnalytics();
        return;
      } catch (e) {
        _toast('No se pudo guardar: $e');
      }
    }

    setState(() {
      _posts.insert(0, FeedPost(
        author: widget.displayName,
        handle: '@user',
        time: 'ahora',
        text: body,
        tag: mediaType ?? 'Nuevo',
        color: Theme.of(context).colorScheme.primary,
        likes: 0,
        mediaUrl: mediaUrl ?? video?.path,
        mediaType: mediaType ?? (video != null ? 'video' : null),
        allowDownload: allow,
        hashtags: tags,
      ));
      _index = 0;
    });
    _toast('Publicación creada en esta sesión');
  }

  Future<void> _submitGame() async {
    final title = TextEditingController();
    final desc = TextEditingController();
    final url = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Enviar juego'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Tu juego quedará pendiente hasta que un admin lo apruebe.'),
            const SizedBox(height: 12),
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Título', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            TextField(controller: desc, maxLines: 3, decoration: const InputDecoration(labelText: 'Descripción', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            TextField(controller: url, decoration: const InputDecoration(labelText: 'URL para jugar / descargar', border: OutlineInputBorder())),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enviar')),
        ],
      ),
    );
    if (ok != true || title.text.trim().isEmpty) {
      title.dispose(); desc.dispose(); url.dispose();
      return;
    }
    if (widget.supabaseReady && !widget.isDemo && Constants.hasSupabaseCredentials) {
      try {
        final uid = Supabase.instance.client.auth.currentUser?.id;
        if (uid == null) throw Exception('Sin sesión');
        await Supabase.instance.client.from('gamess').insert({
          'title': title.text.trim(),
          'description': desc.text.trim(),
          'play_url': url.text.trim().isEmpty ? null : url.text.trim(),
          'created_by': uid,
          'is_official': false,
          'is_approved': false,
        });
        _toast('Juego enviado. Un admin lo revisará.');
      } catch (e) {
        _toast('Error al enviar: $e');
      }
    } else {
      _toast('Juego registrado en demo (sin servidor).');
    }
    title.dispose(); desc.dispose(); url.dispose();
  }

  Future<void> _adminAddSection() async {
    final title = TextEditingController();
    final desc = TextEditingController();
    final key = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nueva sección'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Título', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'Descripción', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          TextField(controller: key, decoration: const InputDecoration(labelText: 'Clave (ej. eventos)', border: OutlineInputBorder())),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Crear')),
        ],
      ),
    );
    if (ok != true || title.text.trim().isEmpty || key.text.trim().isEmpty) {
      title.dispose(); desc.dispose(); key.dispose();
      return;
    }
    if (Constants.hasSupabaseCredentials) {
      try {
        await Supabase.instance.client.from('app_sections').insert({
          'title': title.text.trim(),
          'description': desc.text.trim(),
          'route_key': key.text.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9_]'), ''),
          'created_by': Supabase.instance.client.auth.currentUser?.id,
          'sort_order': 200,
        });
        _toast('Sección creada');
        await _loadSections();
      } catch (e) {
        _toast('Error: $e');
      }
    } else {
      setState(() {
        _extraSections.add(AppSection(title: title.text.trim(), description: desc.text.trim(), routeKey: key.text.trim()));
      });
      _toast('Sección añadida en esta sesión');
    }
    title.dispose(); desc.dispose(); key.dispose();
  }

  Future<void> _download(FeedPost post) async {
    if (!post.allowDownload) {
      _toast('El autor no permite descargar esta publicación');
      return;
    }
    final url = post.mediaUrl;
    if (url == null || url.isEmpty) {
      _toast('No hay archivo para descargar');
      return;
    }
    final uri = Uri.tryParse(url);
    if (uri == null) {
      _toast('URL inválida');
      return;
    }
    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched) _toast('No se pudo abrir la descarga');
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isAdmin = ref.watch(authProvider).isAdmin;
    final dests = [..._base, if (isAdmin) _adminDest];
    if (_index >= dests.length) {
      WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) setState(() => _index = 0); });
    }
    final i = _index.clamp(0, dests.length - 1);
    final page = switch (i) {
      0 => _feed(),
      1 => _games(),
      2 => _chat(),
      3 => _analytics(),
      4 when isAdmin => _admin(),
      _ => _feed(),
    };

    return Scaffold(
      drawer: Drawer(
        child: SafeArea(
          child: ListView(children: [
            DrawerHeader(
              decoration: BoxDecoration(color: theme.colorScheme.primaryContainer.withOpacity(0.4)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.hub_rounded, color: theme.colorScheme.primary, size: 36),
                const SizedBox(height: 8),
                Text('Nexora', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                Text(isAdmin ? 'Modo administrador' : 'Menú', style: theme.textTheme.bodySmall),
              ]),
            ),
            ListTile(leading: const Icon(Icons.home_outlined), title: const Text('Inicio'), onTap: () { Navigator.pop(context); setState(() => _index = 0); }),
            ListTile(leading: const Icon(Icons.tag), title: const Text('Explorar #temas'), onTap: () { Navigator.pop(context); _showHashtagBrowser(); }),
            ListTile(leading: const Icon(Icons.sports_esports_outlined), title: const Text('Juegos'), onTap: () { Navigator.pop(context); setState(() => _index = 1); }),
            for (final s in _extraSections)
              ListTile(
                leading: const Icon(Icons.apps_outlined),
                title: Text(s.title),
                subtitle: s.description.isEmpty ? null : Text(s.description, maxLines: 1, overflow: TextOverflow.ellipsis),
                onTap: () { Navigator.pop(context); _toast('Sección: ${s.title}'); },
              ),
            if (isAdmin) ...[
              const Divider(),
              ListTile(leading: const Icon(Icons.admin_panel_settings_outlined), title: const Text('Panel Admin'), onTap: () { Navigator.pop(context); setState(() => _index = dests.length - 1); }),
              ListTile(leading: const Icon(Icons.add_box_outlined), title: const Text('Añadir sección'), onTap: () { Navigator.pop(context); _adminAddSection(); }),
            ],
          ]),
        ),
      ),
      appBar: AppBar(
        title: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.hub_rounded, color: theme.colorScheme.primary),
          const SizedBox(width: 8),
          const Text('nexora', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -0.4)),
          if (isAdmin) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(color: theme.colorScheme.primary.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
              child: Text('ADMIN', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: theme.colorScheme.primary)),
            ),
          ],
        ]),
        actions: [
          if (_filterHashtag != null)
            Padding(
              padding: const EdgeInsets.only(right: 4),
              child: ActionChip(
                label: Text('#$_filterHashtag'),
                onPressed: () { setState(() => _filterHashtag = null); _loadFeed(); },
                avatar: const Icon(Icons.close, size: 16),
              ),
            ),
          IconButton(tooltip: 'Tema', onPressed: ref.read(themeProvider.notifier).toggleDarkMode, icon: Icon(theme.brightness == Brightness.dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined)),
          IconButton(tooltip: 'Salir', onPressed: _signOut, icon: const Icon(Icons.logout_rounded)),
        ],
      ),
      body: Column(children: [
        if (widget.isDemo || !widget.supabaseReady)
          Material(
            color: theme.colorScheme.primaryContainer.withOpacity(0.35),
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(children: [Icon(Icons.info_outline, size: 18), SizedBox(width: 8), Expanded(child: Text('Modo demo · conecta Supabase para datos reales', style: TextStyle(fontSize: 13)))]),
            ),
          ),
        Expanded(child: page),
      ]),
      floatingActionButton: i == 0
          ? FloatingActionButton.extended(onPressed: _compose, icon: const Icon(Icons.add), label: const Text('Crear'))
          : i == 1
              ? FloatingActionButton.extended(onPressed: _submitGame, icon: const Icon(Icons.upload_rounded), label: const Text('Subir juego'))
              : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v) => setState(() => _index = v),
        destinations: [for (final d in dests) NavigationDestination(icon: Icon(d.icon), selectedIcon: Icon(d.selected), label: d.label)],
      ),
    );
  }

  void _showHashtagBrowser() {
    final ctrl = TextEditingController();
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('Explorar temas', style: Theme.of(ctx).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          TextField(
            controller: ctrl,
            decoration: const InputDecoration(prefixText: '# ', hintText: 'arte, juegos, comunidad…', border: OutlineInputBorder()),
            onSubmitted: (v) {
              final t = v.replaceAll('#', '').trim().toLowerCase();
              if (t.isEmpty) return;
              Navigator.pop(ctx);
              setState(() => _filterHashtag = t);
              _loadFeed(tag: t);
            },
          ),
          const SizedBox(height: 12),
          Wrap(spacing: 8, children: [
            for (final t in ['arte', 'juegos', 'comunidad', 'musica', 'codigo'])
              ActionChip(label: Text('#$t'), onPressed: () {
                Navigator.pop(ctx);
                setState(() => _filterHashtag = t);
                _loadFeed(tag: t);
              }),
          ]),
        ]),
      ),
    );
  }

  Widget _feed() {
    if (_loadingFeed) return const Center(child: CircularProgressIndicator());
    return RefreshIndicator(
      onRefresh: () async { await _loadFeed(tag: _filterHashtag); await _loadAnalytics(); },
      child: ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 96),
        itemCount: _posts.length + 1,
        itemBuilder: (_, idx) {
          if (idx == 0) {
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              StoriesStrip(supabaseReady: widget.supabaseReady, isDemo: widget.isDemo, onToast: _toast),
              Padding(
              padding: const EdgeInsets.only(bottom: 16, top: 4),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_filterHashtag == null ? 'Tu comunidad' : 'Tema #$_filterHashtag', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                Text('Ideas, videos y #temas.', style: TextStyle(color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6))),
              ]),
            ),
              ],
            );
          }
          final post = _posts[idx - 1];
          return _PostCard(
            post: post,
            onLike: () async {
              setState(() { post.liked = !post.liked; post.likes += post.liked ? 1 : -1; });
              if (post.remote && post.id != null && Constants.hasSupabaseCredentials) {
                try {
                  final c = Supabase.instance.client;
                  final uid = c.auth.currentUser?.id;
                  if (uid == null) return;
                  if (post.liked) {
                    await c.from('likes').insert({'user_id': uid, 'post_id': post.id});
                  } else {
                    await c.from('likes').delete().eq('user_id', uid).eq('post_id', post.id!);
                  }
                } catch (_) {}
              }
            },
            onSave: () => setState(() => post.saved = !post.saved),
            onReport: () => _toast('Reporte registrado'),
            onDownload: post.allowDownload ? () => _download(post) : null,
            onTag: (t) { setState(() => _filterHashtag = t); _loadFeed(tag: t); },
          );
        },
      ),
    );
  }

  Widget _analytics() {
    final src = _analyticsFromServer ? 'Datos de tu cuenta (Supabase)' : 'Datos de ejemplo';
    return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
      _Header('Tu actividad', src),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(children: [
          Expanded(child: _Metric(Icons.favorite_outline, 'Me gusta', '$_likesCount', const Color(0xFFEA7891))),
          const SizedBox(width: 10),
          Expanded(child: _Metric(Icons.article_outlined, 'Publicaciones', '$_postsCount', const Color(0xFF7281EB))),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        child: Row(children: [
          Expanded(child: _Metric(Icons.bookmark_border, 'Guardados', '$_savesCount', const Color(0xFFE6A044))),
          const SizedBox(width: 10),
          Expanded(child: _Metric(Icons.flag_outlined, 'Reportes', '$_reportsCount', const Color(0xFF35A98D))),
        ]),
      ),
    ]);
  }

  Widget _admin() {
    return ListView(padding: const EdgeInsets.only(bottom: 24), children: [
      const _Header('Administración', 'Solo role=admin. Los usuarios no ven este panel.'),
      Card(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Moderación y secciones', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 8),
            Text('Reportes pendientes: $_reportsCount'),
            const SizedBox(height: 8),
            const Text('Desde el menú lateral puedes añadir secciones visibles para todos.'),
          ]),
        ),
      ),
      ListTile(leading: const Icon(Icons.add_box_outlined), title: const Text('Añadir sección al menú'), onTap: _adminAddSection),
      ListTile(leading: const Icon(Icons.people_outline), title: const Text('Usuarios y bans'), onTap: () => _toast('RPC admin_set_user_banned')),
      ListTile(leading: const Icon(Icons.block), title: const Text('IPs baneadas'), onTap: () => _toast('Tabla banned_ips + admin_ban_ip')),
      ListTile(leading: const Icon(Icons.sports_esports_outlined), title: const Text('Aprobar juegos pendientes'), onTap: () => _toast('Marca is_approved = true en games')),
      ListTile(leading: const Icon(Icons.tag), title: const Text('Hashtags populares'), onTap: _showHashtagBrowser),
    ]);
  }

  Widget _games() => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Juegos', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Oficiales y de la comunidad. Usa “Subir juego” para enviar el tuyo (queda pendiente de admin).'),
        const SizedBox(height: 12),
        for (final g in [('Laberinto Neón', 'Equipo Nexora · oficial'), ('Memoria Cósmica', 'Equipo Nexora · oficial')])
          Card(child: ListTile(leading: const Icon(Icons.sports_esports_rounded), title: Text(g.$1, style: const TextStyle(fontWeight: FontWeight.w600)), subtitle: Text(g.$2), trailing: const Icon(Icons.play_arrow_rounded))),
      ]);

  Widget _chat() => ChatMediaPage(
        supabaseReady: widget.supabaseReady,
        isDemo: widget.isDemo,
        onToast: _toast,
      );
}

class _Dest {
  const _Dest(this.label, this.selected, this.icon);
  final String label;
  final IconData selected, icon;
}

class _Header extends StatelessWidget {
  const _Header(this.title, this.subtitle);
  final String title, subtitle;
  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: t.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 4),
        Text(subtitle, style: t.textTheme.bodyMedium?.copyWith(color: t.colorScheme.onSurface.withOpacity(0.6))),
      ]),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric(this.icon, this.label, this.value, this.color);
  final IconData icon;
  final String label, value;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 10),
          Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          Text(label, style: Theme.of(context).textTheme.labelMedium?.copyWith(color: Theme.of(context).colorScheme.onSurface.withOpacity(0.65))),
        ]),
      ),
    );
  }
}

class _PostCard extends StatelessWidget {
  const _PostCard({required this.post, required this.onLike, required this.onSave, required this.onReport, this.onDownload, this.onTag});
  final FeedPost post;
  final VoidCallback onLike, onSave, onReport;
  final VoidCallback? onDownload;
  final void Function(String tag)? onTag;
  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            CircleAvatar(backgroundColor: post.color.withOpacity(0.2), child: Text(post.author.isNotEmpty ? post.author[0].toUpperCase() : '?', style: TextStyle(color: post.color, fontWeight: FontWeight.w700))),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(post.author, style: const TextStyle(fontWeight: FontWeight.w700)),
              Text('${post.handle} · ${post.time}', style: t.textTheme.bodySmall?.copyWith(color: t.colorScheme.onSurface.withOpacity(0.55))),
            ])),
            Chip(label: Text(post.tag, style: const TextStyle(fontSize: 11)), visualDensity: VisualDensity.compact),
          ]),
          const SizedBox(height: 12),
          Text(post.text, style: t.textTheme.bodyLarge?.copyWith(height: 1.35)),
          if (post.hashtags.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(spacing: 6, runSpacing: 4, children: [
              for (final h in post.hashtags)
                ActionChip(label: Text('#$h', style: const TextStyle(fontSize: 12)), visualDensity: VisualDensity.compact, onPressed: onTag == null ? null : () => onTag!(h)),
            ]),
          ],
          if (post.mediaType == 'video' && post.mediaUrl != null) ...[
            const SizedBox(height: 8),
            Container(
              height: 120,
              width: double.infinity,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: t.colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(12)),
              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.play_circle_outline, size: 36), SizedBox(width: 8), Text('Video')]),
            ),
          ],
          const SizedBox(height: 8),
          Row(children: [
            IconButton(onPressed: onLike, icon: Icon(post.liked ? Icons.favorite : Icons.favorite_border, color: post.liked ? Colors.redAccent : null)),
            Text('${post.likes}'),
            IconButton(onPressed: onSave, icon: Icon(post.saved ? Icons.bookmark : Icons.bookmark_border)),
            if (onDownload != null) IconButton(onPressed: onDownload, icon: const Icon(Icons.download_rounded), tooltip: 'Descargar'),
            const Spacer(),
            IconButton(onPressed: onReport, icon: const Icon(Icons.flag_outlined), tooltip: 'Reportar'),
          ]),
        ]),
      ),
    );
  }
}
