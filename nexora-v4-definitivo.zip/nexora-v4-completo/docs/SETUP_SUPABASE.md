# Setup Supabase para Nexora v4 (producción / APK distribuible)

## 1. Crear proyecto en Supabase (gratis)

1. Entra a https://supabase.com → **New project**
2. Nombre: `nexora` (o el que quieras)
3. Región cercana a tus usuarios
4. Genera una **Database Password** fuerte y **guárdala**
5. Espera ~1-2 min a que el proyecto esté listo

## 2. Obtener las claves (las que necesitas)

Ve a **Project Settings → API**:

| Clave | Dónde usarla | ¿Va en el APK? |
|-------|--------------|----------------|
| **Project URL** | `SUPABASE_URL` | Sí (pública) |
| **anon / public** key | `SUPABASE_ANON_KEY` | Sí (pública + RLS) |
| **service_role** key | Solo backend / scripts admin | **NUNCA** en el APK |

Copia:

```
SUPABASE_URL=https://XXXXXXXX.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9....
```

## 3. Ejecutar los SQL (en orden)

En el Dashboard → **SQL Editor** → New query → pega y ejecuta uno por uno:

1. `supabase/schema_base.sql`          ← tablas base + RLS + bucket media
2. `supabase/schema_v4.sql`            ← stories + media en messages + bucket stories

(Si tienes schema_v2 / v3 antiguos, ejecútalos antes de v4.)

## 4. Auth

- **Authentication → Providers** → Email activado (y Google/Apple si quieres)
- **URL Configuration** → Site URL: `io.nexora.app://login-callback/` (o el deep link de Flutter)
- Redirect URLs: añade las de tu app

## 5. Storage

Los buckets `media` y `stories` se crean con el SQL.
Verifica en **Storage** que existen y que las policies están activas.

## 6. Conectar la app Flutter

### Opción A – Desarrollo (recomendado)

```bash
cp .env.example .env
# Edita .env con tu URL y anon key
flutter pub get
flutter run
```

### Opción B – Build APK de producción (sin .env en el APK)

```bash
flutter build apk --release \
  --dart-define=SUPABASE_URL=https://XXXXXXXX.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9....
```

O usa un archivo de secrets en CI (GitHub Actions).

## 7. Seguridad para distribución masiva

- La **anon key** es pública por diseño. La seguridad la dan las **Row Level Security (RLS)** policies del SQL.
- Nunca pongas la `service_role` key en el código del cliente.
- Revisa que las policies de `stories`, `messages`, `posts` y storage solo permitan lo necesario.
- Activa **Auth rate limits** y considera CAPTCHA en sign-up si esperas abuso.

## 8. Limpieza de stories vencidos (opcional)

Puedes programar con **pg_cron** (extensión de Supabase):

```sql
select cron.schedule(
  'cleanup-stories',
  '0 * * * *',  -- cada hora
  $$ select public.cleanup_expired_stories(); $$
);
```

---

**Importante:** Yo (Grok) no puedo crear el proyecto de Supabase ni generar las llaves reales por ti. Debes hacerlo en el dashboard de Supabase. Las llaves son únicas por proyecto.
