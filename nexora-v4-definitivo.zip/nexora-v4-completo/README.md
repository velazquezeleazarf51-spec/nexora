# Nexora v4 · X + Instagram + WhatsApp

Feed estilo X · Stories 24h estilo Instagram · Chat con media estilo WhatsApp  
Backend: **Supabase** (Auth + Postgres + Storage + Realtime)

## Contenido de este ZIP definitivo

```
nexora-v4-completo/
├── lib/
│   ├── main.dart
│   ├── core/constants.dart          ← lee SUPABASE_URL / ANON_KEY de forma segura
│   └── features/
│       ├── home/home_screen.dart
│       ├── stories/stories_strip.dart
│       └── chat/chat_media_page.dart
├── supabase/
│   ├── schema_base.sql              ← ejecutar PRIMERO
│   └── schema_v4.sql                ← stories + media en chat
├── docs/
│   ├── NEXORA_X_IG_WA.md
│   ├── SETUP_SUPABASE.md            ← guía completa de conexión
│   └── QUE_FALTA.md
├── .github/workflows/build-apk.yml  ← CI para generar APK
├── .env.example
├── .gitignore
└── pubspec.yaml
```

## Conexión rápida (lo que necesitas copiar/pegar)

1. Crea proyecto en https://supabase.com
2. Ve a **Settings → API** y copia:

```
SUPABASE_URL=https://TU-PROYECTO.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9....
```

3. Ejecuta en el SQL Editor (en este orden):
   - `schema_base.sql`
   - `schema_v4.sql`

4. En tu máquina:

```bash
cp .env.example .env
# pega las dos líneas de arriba en .env
flutter pub get
flutter run
```

5. Para APK de distribución:

```bash
flutter build apk --release \
  --dart-define=SUPABASE_URL=https://TU-PROYECTO.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=eyJ...
```

## Seguridad (importante porque el APK se va a esparcir)

- La **anon key** es pública. La seguridad real la dan las **RLS policies** del SQL.
- **Nunca** pongas la `service_role` key en el código del cliente ni en el APK.
- El workflow de GitHub Actions usa **Secrets** (Settings → Secrets and variables → Actions):
  - `SUPABASE_URL`
  - `SUPABASE_ANON_KEY`

## Qué sigue

Si tienes más archivos del proyecto (auth, providers, android completo, etc.) súbelos y los integro.
Si solo tienes esto, con lo de este ZIP + tu proyecto Supabase ya puedes probar Stories + Chat con media + Feed.
